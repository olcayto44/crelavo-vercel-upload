import { readFileSync } from "node:fs";
import { allCreditProducts, packages, topUpPackages, stripePriceEnvForCreditProduct } from "../src/lib/data.ts";
import { billingTermsText, LEGAL_ACCEPTANCE_VERSION, legalAcceptanceSnapshot } from "../src/lib/legal.ts";

function assert(condition: boolean, message: string) {
  if (!condition) throw new Error(message);
}

assert(packages.length >= 4, "subscription packages missing");
assert(topUpPackages.length >= 3, "top-up packages missing");
assert(packages.every((plan) => plan.planType === "subscription"), "all main packages must be subscriptions");
assert(topUpPackages.every((plan) => plan.planType === "topup"), "all top-up packages must be one-time top-ups");
assert(packages.some((plan) => plan.name === "Pro" && plan.renderQueue === "Priority render queue"), "Pro should include priority render queue");
assert(packages.some((plan) => plan.name === "Business" && plan.renderQueue === "Fastest render queue"), "Business should include fastest render queue");
assert(packages.some((plan) => plan.name === "Team" && plan.renderQueue === "Dedicated production priority"), "Team should include dedicated production priority");
assert(allCreditProducts.length === packages.length + topUpPackages.length, "all credit products should include subscriptions and top-ups");

for (const plan of packages) {
  assert(stripePriceEnvForCreditProduct(plan, "monthly").includes("_MONTHLY"), `${plan.name} monthly stripe env missing`);
  assert(stripePriceEnvForCreditProduct(plan, "yearly").includes("_YEARLY"), `${plan.name} yearly stripe env missing`);
}
for (const plan of topUpPackages) {
  assert(stripePriceEnvForCreditProduct(plan, "one_time").includes("TOPUP"), `${plan.name} top-up stripe env missing`);
}

assert(LEGAL_ACCEPTANCE_VERSION.includes("subscription-billing"), "legal version should include subscription billing update");
assert(billingTermsText.includes("renew automatically"), "billing terms should mention auto renewal");
assert(billingTermsText.includes("One-time top-up credit packages are not subscriptions"), "billing terms should mention one-time top-ups");
const snapshot = legalAcceptanceSnapshot({ productionType: "video", packageId: "pro", title: "Test" });
assert("billingTermsText" in snapshot, "legal snapshot should store billing terms");

const checkoutRoute = readFileSync("src/app/api/stripe/checkout/route.ts", "utf8");
for (const term of ["mode: checkoutMode", "subscription_data", "payment_intent_data", "credit_subscription", "credit_topup", "priceEnv", "process.env[priceEnv]"]) {
  assert(checkoutRoute.includes(term), `checkout route missing term: ${term}`);
}

const webhookRoute = readFileSync("src/app/api/stripe/webhook/route.ts", "utf8");
for (const term of ["invoice.paid", "invoice.payment_failed", "customer.subscription.updated", "customer.subscription.deleted", "Subscription payment failed"]) {
  assert(webhookRoute.includes(term), `webhook missing subscription term: ${term}`);
}

const paymentPage = readFileSync("src/app/dashboard/payment/page.tsx", "utf8");
for (const term of ["Start recurring credit subscription", "Buy one-time top-up credits", "billingTermsText", "StripeCheckoutButton", "does not renew automatically"]) {
  assert(paymentPage.includes(term), `payment page missing term: ${term}`);
}

const creditsPage = readFileSync("src/app/dashboard/credits/page.tsx", "utf8");
assert(creditsPage.includes("topUpPackages"), "credits page should render top-up packages");

const envExample = readFileSync(".env.example", "utf8");
for (const term of ["STRIPE_PRICE_PRO_MONTHLY", "STRIPE_PRICE_PRO_YEARLY", "STRIPE_PRICE_TOPUP_STARTER", "STRIPE_PRICE_TOPUP_CREATOR", "STRIPE_PRICE_TOPUP_BUSINESS"]) {
  assert(envExample.includes(term), `.env.example missing ${term}`);
}

console.log("subscription-billing-smoke ok");
