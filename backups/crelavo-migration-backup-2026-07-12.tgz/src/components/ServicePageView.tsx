import Link from "next/link";
import { ServicePageStructuredData } from "@/components/ServicePageStructuredData";
import type { ServicePage } from "@/lib/service-pages";

const relatedPages = [
  { href: "/ai-website-builder", label: "AI Website Builder" },
  { href: "/ai-app-builder", label: "AI App Builder" },
  { href: "/ai-ecommerce-builder", label: "AI Ecommerce Builder" },
  { href: "/ai-video-generator", label: "AI Video Generator" },
  { href: "/ai-social-media-ai", label: "AI Social Media AI" }
];

function exampleHref(baseHref: string, example: string) {
  const separator = baseHref.includes("?") ? "&" : "?";
  return `${baseHref}${separator}example=${encodeURIComponent(example)}`;
}

function buildSeoArticle(page: ServicePage) {
  const [firstSection, secondSection] = page.sections;
  return [
    {
      title: `What is ${page.keyword}?`,
      paragraphs: [
        `${page.keyword} is a focused Clipora Studio service path for users who want to move from an idea into a managed AI production workflow. Instead of sending users directly into a blank dashboard, this guide explains what the service does, what inputs are useful, what outputs can be prepared and how the final delivery can be tracked. For ${page.title}, the main goal is to help users understand the production path before they spend credits or request a live provider job.`,
        `${page.summary} This makes the page useful for search visitors, returning users and dashboard users who need a clear starting point. Clipora positions each service as a delivery workflow, not only a prompt form, so the user can see what will be prepared and what kind of handoff can be expected.`
      ]
    },
    {
      title: `What Clipora can deliver for ${page.title}`,
      paragraphs: [
        `The ${page.title} workflow is best for ${page.bestFor}. A user can start with inputs such as ${page.inputs.join(", ").toLowerCase()} and continue into a structured production request. Clipora can organize the request into outputs such as ${page.outputs.join(", ").toLowerCase()}, then route the user toward the right workspace, package or delivery center.`,
        firstSection?.text ?? `This workflow helps turn an unclear request into a production-ready plan with delivery expectations, credit awareness and dashboard tracking.`
      ]
    },
    {
      title: `${page.title} delivery formats`,
      paragraphs: [
        `A key part of Clipora is delivery clarity. Depending on the selected package and provider readiness, ${page.title} projects can be prepared with ${page.delivery.join(", ").toLowerCase()}. This helps users understand the difference between a preview, a final package, editable source material, setup notes and revision tracking.`,
        secondSection?.text ?? `The service is designed so each request can become a usable production package instead of disappearing into a simple chat response.`
      ]
    },
    {
      title: `Start your ${page.title} workflow`,
      paragraphs: [
        `Users can begin from this public page, compare delivery expectations on the pricing page, or continue into the dashboard when they are ready. Example uses include ${page.examples.join(", ").toLowerCase()}. The goal is to keep the path simple: understand the service, choose the right workflow, start the assistant-guided request and receive a clear production delivery path.`,
        `Clipora keeps this service content aligned with the real production system as the platform grows. That means the page can stay connected to current delivery options, provider readiness, examples, pricing paths and assistant-guided workflows.`
      ]
    }
  ];
}

export function ServicePageView({ page }: { page: ServicePage }) {
  const article = buildSeoArticle(page);
  const related = relatedPages.filter((item) => item.href !== `/${page.slug}`).slice(0, 4);

  return (
    <>
      <ServicePageStructuredData page={page} />
      <main className="container section service-page-detail">
        <section className="production-hero-card admin-overview-hero service-hero-card">
        <span className="badge">{page.badge}</span>
        <h1>{page.title}</h1>
        <p>{page.summary}</p>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 16 }}>
          <Link className="btn" href={page.primaryCtaHref}>{page.primaryCtaLabel}</Link>
          {page.secondaryCtaHref ? <Link className="btn secondary" href={page.secondaryCtaHref}>View pricing and delivery options</Link> : null}
          <Link className="btn secondary" href="/tools">All tools</Link>
        </div>
      </section>

      <section className="admin-info-grid service-info-grid" style={{ marginTop: 18 }}>
        <div><span>Service</span><strong>{page.keyword}</strong><small>Main production category</small></div>
        <div><span>Best for</span><strong>{page.bestFor}</strong><small>Recommended use case</small></div>
        <div><span>Delivery</span><strong>{page.delivery.slice(0, 3).join(" + ")}</strong><small>Handoff formats</small></div>
        <div><span>Ready path</span><strong>Assistant workflow</strong><small>Continue with guided production</small></div>
      </section>

      <section className="service-three-col" style={{ marginTop: 18 }}>
        <div className="card admin-category-card"><span className="badge">Inputs</span><h2>What the user provides</h2>{page.inputs.map((item) => <p key={item}>{item}</p>)}</div>
        <div className="card admin-category-card"><span className="badge">Outputs</span><h2>What Clipora prepares</h2>{page.outputs.map((item) => <p key={item}>{item}</p>)}</div>
        <div className="card admin-category-card"><span className="badge">Delivery</span><h2>How it can be delivered</h2>{page.delivery.map((item) => <p key={item}>{item}</p>)}</div>
      </section>

      <article className="card admin-wide-card service-seo-article" style={{ marginTop: 18 }}>
        <span className="badge">Service guide</span>
        {article.map((section) => (
          <section key={section.title}>
            <h2>{section.title}</h2>
            {section.paragraphs.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
          </section>
        ))}
      </article>

      <section className="card admin-wide-card" style={{ marginTop: 18 }}>
        <span className="badge">Example uses</span>
        <h2>{page.title} examples</h2>
        <div className="admin-category-grid">
          {page.examples.map((item) => (
            <Link className="card admin-category-card" href={exampleHref(page.primaryCtaHref, item)} key={item}>
              <span className="badge">{page.keyword}</span>
              <h3>{item}</h3>
              <p>Use this example as the starting brief for the {page.title} workflow.</p>
            </Link>
          ))}
        </div>
      </section>

      {page.faqItems?.length ? (
        <section className="card admin-wide-card" style={{ marginTop: 18 }}>
          <span className="badge">FAQ</span>
          <h2>{page.title} questions</h2>
          <div className="admin-category-grid">
            {page.faqItems.map((item) => <div className="card admin-category-card" key={item.question}><h3>{item.question}</h3><p>{item.answer}</p></div>)}
          </div>
        </section>
      ) : null}

      {page.internalLinks?.length ? (
        <section className="card admin-wide-card" style={{ marginTop: 18 }}>
          <span className="badge">Next paths</span>
          <h2>Continue from this service</h2>
          <div className="plan-feature-groups">
            {page.internalLinks.map((item) => <Link href={item.href} key={`${item.label}-${item.href}`}><b>{item.label}</b><small>Open recommended path</small></Link>)}
          </div>
        </section>
      ) : null}

      <section className="card admin-wide-card" style={{ marginTop: 18 }}>
        <span className="badge">Related services</span>
        <h2>Explore related Clipora services</h2>
        <div className="plan-feature-groups">
          {related.map((item) => <Link href={item.href} key={item.href}><b>{item.label}</b><small>Open this related service</small></Link>)}
          <Link href="/pricing"><b>Pricing and delivery options</b><small>Review credits, ZIP/source/README and handoff options</small></Link>
          <Link href="/dashboard/productions"><b>Production Delivery Center</b><small>Track previews, final packages, source files and revisions</small></Link>
        </div>
      </section>
    </main>
  </>
);
}
