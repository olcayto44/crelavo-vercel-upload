"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import type { FreeTool } from "@/lib/free-tools";

function cleanInput(value: string) {
  return value.trim().replace(/\s+/g, " ");
}

function topic(input: string) {
  return cleanInput(input) || "your product or idea";
}

function generateOutputs(tool: FreeTool, input: string) {
  const idea = topic(input);

  switch (tool.slug) {
    case "tiktok-hook-generator":
      return [
        `Nobody tells you this about ${idea}...`,
        `I tried ${idea} so you do not have to.`,
        `If you care about ${idea}, watch this before you scroll.`,
        `The fastest way to understand ${idea} in 15 seconds.`
      ];
    case "ai-prompt-generator":
      return [
        `Create a clear, high-converting production concept for ${idea}. Include the target audience, visual direction, key benefits, required assets and final delivery format.`,
        `Turn ${idea} into a structured AI production brief with sections for goal, style, content, output files, revision notes and CTA.`,
        `Generate a premium marketing asset for ${idea} with a concise concept, scene plan, copy direction and delivery-ready export notes.`
      ];
    case "product-description-generator":
      return [
        `${idea} helps customers solve a specific problem with a simple, practical and easy-to-understand solution. It is designed for buyers who want reliable results without extra complexity.`,
        `Present ${idea} as a benefit-led product: highlight the main problem, show the transformation, explain the key features and finish with a direct buying reason.`,
        `Short version: ${idea} gives customers a faster, cleaner and more confident way to get the result they want.`
      ];
    case "youtube-title-generator":
      return [
        `I Tested ${idea} — Here Is What Happened`,
        `How ${idea} Works in Real Life`,
        `Before You Try ${idea}, Watch This`,
        `The Simple ${idea} Strategy Nobody Explains`
      ];
    case "instagram-caption-generator":
      return [
        `Building something around ${idea}? Start simple, show the value, and make every post lead to one clear next step.`,
        `${idea} is not just an idea — it is a way to move faster, explain better and launch with more confidence.`,
        `New drop: ${idea}. Clear value, clean execution, and a delivery path built for real output.`
      ];
    case "hashtag-generator":
      return [
        `#${idea.replace(/[^a-zA-Z0-9]+/g, "").toLowerCase()} #aitools #digitalproduct #contentcreator #startup`,
        `#productlaunch #smallbusiness #ecommerce #marketingtools #growth`,
        `#aigenerator #socialmedia #brandbuilding #onlinebusiness #creatorbusiness`
      ];
    case "business-name-generator":
      return [
        `${idea.split(" ")[0] || "Nova"} Studio`,
        `Bright ${idea.split(" ")[0] || "Launch"}`,
        `${idea.split(" ")[0] || "Core"} Works`,
        `LaunchGrid`,
        `ProductPilot`
      ];
    case "landing-page-copy-generator":
      return [
        `Headline: Launch ${idea} faster with a clear production-ready workflow.`,
        `Subheadline: Turn your idea into a structured page, content package and delivery path without starting from a blank screen.`,
        `CTA: Start your ${idea} project today.`,
        `Section idea: Show the problem, explain the outcome, list the deliverables, then invite the user to start production.`
      ];
    case "ad-copy-generator":
      return [
        `Stop wasting time trying to explain ${idea}. Turn it into a clear offer, a simple message and a delivery-ready campaign.`,
        `${idea} made simple: show the value, build trust, and give customers one clear reason to act now.`,
        `Need a faster way to launch ${idea}? Start with a production plan, then turn it into real assets.`
      ];
    case "tiktok-ad-script-generator":
      return [
        `Hook: "If you are working on ${idea}, this will save you time."\nScene 1: Show the problem.\nScene 2: Show the result.\nCTA: "Try it and turn it into a full production package."`,
        `Hook: "I found a faster way to create ${idea}."\nDemo: Show before/after.\nProof: Mention speed and delivery.\nCTA: "Open the assistant to build the full version."`
      ];
    case "youtube-shorts-script-generator":
      return [
        `0-3s: Introduce ${idea} with a strong hook.\n3-15s: Explain the main benefit.\n15-25s: Show an example.\n25-30s: Add a clear CTA.`,
        `Start with the problem, reveal ${idea}, show the quick win, and end with "build the full version in Clipora."`
      ];
    case "ecommerce-product-idea-generator":
      return [
        `${idea} starter product bundle for a specific niche audience.`,
        `A premium version of ${idea} with better packaging, clearer benefits and social video angles.`,
        `${idea} accessory or add-on product that can be sold with a simple product page and TikTok ad.`
      ];
    case "startup-idea-generator":
      return [
        `A SaaS tool that helps teams manage ${idea} from idea to delivery.`,
        `A marketplace for people who need ${idea} services faster and with clearer output tracking.`,
        `An AI assistant that turns ${idea} requests into structured workflows, deliverables and client-ready packages.`
      ];
    case "seo-meta-title-generator":
      return [
        `${idea} — Fast, Clear and Production-Ready`,
        `Best ${idea} Tool for Creators and Small Businesses`,
        `${idea}: Create Better Outputs Faster`
      ];
    case "brand-slogan-generator":
      return [
        `${idea}, made simple.`,
        `Launch faster with ${idea}.`,
        `Create more with less friction.`,
        `From idea to delivery.`
      ];
    default:
      return tool.sampleOutputs.map((output) => `${output}: ${idea}`);
  }
}

function assistantUrl(tool: FreeTool, input: string, selectedOutput: string) {
  const idea = [
    `${tool.title} result`,
    input.trim() ? `Original input: ${input.trim()}` : "",
    selectedOutput ? `Selected result: ${selectedOutput}` : "",
    "Turn this into a full Clipora production package with deliverables, preview, final files and revision path."
  ].filter(Boolean).join("\n\n");
  const base = new URL(tool.assistantHref, "http://localhost");
  base.searchParams.set("idea", idea);
  base.searchParams.set("source", "free-tool");
  base.searchParams.set("tool", tool.slug);
  return `${base.pathname}?${base.searchParams.toString()}`;
}

export function FreeToolGenerator({ tool }: { tool: FreeTool }) {
  const [input, setInput] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [selectedOutput, setSelectedOutput] = useState("");
  const outputs = useMemo(() => generateOutputs(tool, input), [tool, input]);
  const activeOutput = selectedOutput || outputs[0] || "";
  const workspaceHref = assistantUrl(tool, input, activeOutput);
  const registerHref = `/auth/register?next=${encodeURIComponent(workspaceHref)}`;
  const loginHref = `/auth/login?next=${encodeURIComponent(workspaceHref)}`;

  return (
    <section className="card admin-wide-card free-tool-generator" style={{ marginTop: 18 }}>
      <span className="badge">Free generator</span>
      <h2>Generate results instantly</h2>
      <div className="field">
        <label>{tool.placeholder}</label>
        <textarea value={input} onChange={(event) => setInput(event.target.value)} placeholder={tool.placeholder} rows={4} />
      </div>
      <button className="btn" type="button" onClick={() => { setSubmitted(true); setSelectedOutput(""); }} style={{ marginTop: 12 }}>Generate free results</button>

      {submitted ? (
        <div className="admin-category-grid" style={{ marginTop: 14 }}>
          {outputs.map((output, index) => (
            <div className="card admin-category-card" key={output}>
              <span className="badge">{activeOutput === output ? "Selected result" : "Generated result"}</span>
              <p style={{ whiteSpace: "pre-line" }}>{output}</p>
              <button className="btn secondary" type="button" onClick={() => setSelectedOutput(output)} style={{ marginTop: 10 }}>{activeOutput === output ? "Selected for production" : `Use result ${index + 1}`}</button>
            </div>
          ))}
        </div>
      ) : (
        <div className="admin-category-grid" style={{ marginTop: 14 }}>
          {tool.sampleOutputs.map((output) => (
            <div className="card admin-category-card" key={output}>
              <span className="badge">Example</span>
              <p>{output}</p>
            </div>
          ))}
        </div>
      )}

      <div className="card admin-wide-card" style={{ marginTop: 16 }}>
        <span className="badge">Next step</span>
        <h2>Turn the selected result into a production request</h2>
        <p style={{ color: "var(--muted)", whiteSpace: "pre-line" }}>{activeOutput}</p>
        <div className="workspace-action-note" style={{ marginTop: 12 }}>
          Free tools are the starting point. Assistant Workspace turns the selected result into a full production request with delivery plan, credits and final package options.
        </div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 16 }}>
          <Link className="btn" href={workspaceHref}>Start production with this result</Link>
          <Link className="btn secondary" href={registerHref}>Create account and keep this result</Link>
          <Link className="btn secondary" href={loginHref}>Sign in and continue</Link>
          <Link className="btn secondary" href="/dashboard/credits">Get free credits</Link>
          <Link className="btn secondary" href="/pricing">Credit packages</Link>
          <Link className="btn secondary" href="/free-tools">All free tools</Link>
        </div>
        <small style={{ color: "var(--muted)", display: "block", marginTop: 10 }}>The Assistant Workspace will open with your input and selected result already included. If you buy credits through a Stripe Payment Link, use the same email as your Clipora account.</small>
      </div>
    </section>
  );
}
