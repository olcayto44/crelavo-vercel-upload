"use client";

import Link from "next/link";
import { useState } from "react";
import { CreditCard } from "lucide-react";

type CreditPlan = {
  name: string;
  billing: string;
  price: string;
  priceUsd?: number;
  credits: number;
  description: string;
  estimatedOutput?: string;
  videoSpec?: string;
  mediaIncluded?: string;
  modelAccess?: string[];
  automationAccess?: string[];
  concurrentTasks?: number;
  relaxMode?: string;
  teamFeatures?: string[];
  usage?: string[];
  id?: string;
  planType?: string;
};

function formatUsd(value: number) {
  return `$${value.toLocaleString("en-US")}`;
}

function planPrice(plan: CreditPlan, billingMode: "monthly" | "yearly") {
  if (!plan.priceUsd) return plan.price;
  const suffix = plan.name === "Team" ? "/seat" : "";
  return billingMode === "monthly" ? `$${plan.priceUsd}${suffix}/mo` : `${formatUsd(plan.priceUsd * 11)}${suffix}/yr`;
}

function planCredits(plan: CreditPlan, billingMode: "monthly" | "yearly") {
  return billingMode === "monthly" ? plan.credits : plan.credits * 12;
}

export function CreditPlansToggle({ plans, ctaLabel = "Choose package" }: { plans: CreditPlan[]; ctaLabel?: string }) {
  const [billingMode, setBillingMode] = useState<"monthly" | "yearly">("monthly");
  const isTopUpList = plans.every((plan) => plan.planType === "topup");

  return (
    <section className="credit-plan-section">
      <div className="credit-plan-head">
        <div>
          <span className="badge"><CreditCard size={14} /> {isTopUpList ? "One-time credit purchases" : "Recurring credit subscriptions"}</span>
          <h2>{isTopUpList ? "Buy extra credits whenever you need them" : "Choose a monthly or yearly credit subscription"}</h2>
          <p className="section-lead">{isTopUpList ? "Extra credit packages are one-time purchases, do not renew automatically, and can be bought repeatedly." : "Subscriptions renew automatically. With yearly billing, you receive 12 months of credits and pay for 11 months. One month is free in every package."}</p>
        </div>
        {!isTopUpList ? (
          <div className="billing-toggle" aria-label="Billing period selection">
            <button className={billingMode === "monthly" ? "active" : ""} type="button" onClick={() => setBillingMode("monthly")}>Monthly</button>
            <button className={billingMode === "yearly" ? "active" : ""} type="button" onClick={() => setBillingMode("yearly")}>Yearly</button>
            <span className={`billing-toggle-thumb ${billingMode}`} />
          </div>
        ) : null}
      </div>

      <div className="grid credit-plan-grid" style={{ marginTop: 14 }}>
        {plans.map((plan) => {
          const effectiveBilling = plan.planType === "topup" ? "one_time" : billingMode;
          const credits = plan.planType === "topup" ? plan.credits : planCredits(plan, billingMode);
          const price = plan.planType === "topup" ? plan.price : planPrice(plan, billingMode);
          const productId = plan.id ?? plan.name;
          const isRecommended = plan.priceUsd === 79 || plan.name.toLowerCase() === "business";
          const normalizedPlanName = plan.name.toLowerCase().replace(/[^a-z0-9]+/g, "-");
          const planTone = plan.planType === "topup" ? `topup-${normalizedPlanName}` : isRecommended ? "recommended" : normalizedPlanName;
          return (
            <Link className={`card clickable-credit-card credit-sale-card credit-plan-tone-${planTone}${isRecommended ? " recommended-credit-plan" : ""}`} href={`/dashboard/payment?package=${encodeURIComponent(productId)}&billing=${effectiveBilling}`} key={plan.name}>
              <span className="badge">{isRecommended ? "Recommended credit plan" : plan.planType === "topup" ? "One-time credit purchase" : billingMode === "monthly" ? "Monthly subscription" : "Yearly subscription - 1 month free"}</span>
              <h3>{plan.name}</h3>
              <strong>{price}</strong>
              <p className="plan-credit-line"><b>{credits.toLocaleString()} credits</b> are added to the account.</p>
              {plan.planType !== "topup" && billingMode === "yearly" && plan.priceUsd ? <p className="plan-savings-line">Normally {formatUsd(plan.priceUsd * 12)}/yr, now {formatUsd(plan.priceUsd * 11)}/yr.</p> : null}
              <div className="plan-value-stack compact">
                {plan.estimatedOutput ? <div><span>Estimated output</span><b>{plan.estimatedOutput}</b></div> : null}
                {plan.videoSpec ? <div><span>Video quality/duration</span><b>{plan.videoSpec}</b></div> : null}
                {plan.mediaIncluded ? <div><span>Material + audio</span><b>{plan.mediaIncluded}</b></div> : null}
                {typeof plan.concurrentTasks === "number" ? <div><span>Concurrent task</span><b>{plan.concurrentTasks} simultaneous jobs</b></div> : null}
              </div>
              <p>{plan.description}</p>
              <div className="plan-feature-groups">
                {plan.modelAccess?.length ? <div><b>Model access</b>{plan.modelAccess.map((item) => <small key={item}>{item}</small>)}</div> : null}
                {plan.automationAccess?.length ? <div><b>Automation</b>{plan.automationAccess.map((item) => <small key={item}>{item}</small>)}</div> : null}
                {plan.relaxMode ? <div><b>Relax mode</b><small>{plan.relaxMode}</small></div> : null}
                {plan.teamFeatures?.length ? <div><b>Team / workspace</b>{plan.teamFeatures.map((item) => <small key={item}>{item}</small>)}</div> : null}
              </div>
              <span className="btn">{ctaLabel}</span>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
