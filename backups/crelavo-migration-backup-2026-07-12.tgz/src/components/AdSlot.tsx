import { getConfiguredAdSlots } from "@/lib/ad-config";

export async function AdSlot({ slotId }: { slotId: string }) {
  const slots = await getConfiguredAdSlots();
  const slot = slots.find((item) => item.id === slotId && item.status === "active" && item.code.trim());

  if (!slot) return null;

  return (
    <section className="container ad-slot-section" aria-label={slot.name}>
      <div className="ad-slot-frame" style={{ minHeight: Math.min(slot.height, 280) }}>
        <span className="ad-slot-label">Ad · {slot.size}</span>
        <div className="ad-slot-code" dangerouslySetInnerHTML={{ __html: slot.code }} />
      </div>
    </section>
  );
}
