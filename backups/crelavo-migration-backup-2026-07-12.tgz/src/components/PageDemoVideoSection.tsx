import Link from "next/link";
import { PlayCircle } from "lucide-react";
import type { SampleVideo } from "@/lib/sample-videos";

type PageDemoVideoSectionProps = {
  sample?: SampleVideo;
  badge: string;
  title: string;
  description: string;
  fallbackFeatures: string[];
  ctaHref: string;
  ctaLabel: string;
  secondaryHref?: string;
  secondaryLabel?: string;
  adminHint: string;
};

export function pickPageDemoVideo(videos: SampleVideo[], keys: string[]) {
  const normalizedKeys = keys.map((key) => key.toLowerCase());
  return videos.find((item) => {
    const haystack = [item.id, item.category, item.title].join(" ").toLowerCase();
    return normalizedKeys.some((key) => haystack.includes(key));
  });
}

export function PageDemoVideoSection({ sample, badge, title, description, fallbackFeatures, ctaHref, ctaLabel, secondaryHref, secondaryLabel, adminHint }: PageDemoVideoSectionProps) {
  const videoTitle = sample?.title || title;
  const videoDescription = sample?.description || description;
  const placeholderText = sample?.features?.length ? sample.features.join(" • ") : fallbackFeatures.join(" • ");
  void adminHint;

  return (
    <section className="page-demo-video-section showcase-detail-hero tone-green">
      <div className="showcase-detail-copy">
        <span className="badge">{badge}</span>
        <h2 className="page-demo-showcase-title">{videoTitle}</h2>
        <p>{videoDescription}</p>
        <div className="showcase-detail-actions">
          <Link className="btn" href={ctaHref}>{ctaLabel}</Link>
          {secondaryHref && secondaryLabel ? <Link className="btn secondary" href={secondaryHref}>{secondaryLabel}</Link> : null}
        </div>
      </div>
      <div className="showcase-video-panel" aria-label={`${title} information video area`}>
        {sample?.videoUrl ? (
          <video className="showcase-detail-video" src={sample.videoUrl} poster={sample.thumbnailUrl} controls playsInline preload="metadata" />
        ) : (
          <>
            <div className="showcase-video-art" style={sample?.thumbnailUrl ? { backgroundImage: `linear-gradient(180deg, rgba(2,6,23,.10), rgba(2,6,23,.78)), url(${sample.thumbnailUrl})` } : undefined} />
            <div className="showcase-video-overlay">
              <span><PlayCircle size={46} /></span>
              <strong>{title}</strong>
              <p>{placeholderText}</p>
              <small>Video placeholder — demo/explainer video can be connected here.</small>
            </div>
          </>
        )}
      </div>
    </section>
  );
}
