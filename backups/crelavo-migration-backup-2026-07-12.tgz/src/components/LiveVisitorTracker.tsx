"use client";

import { useEffect } from "react";
import { usePathname, useSearchParams } from "next/navigation";

const SESSION_KEY = "clipora_live_session_id";

function getSessionId() {
  if (typeof window === "undefined") return "";
  const existing = window.sessionStorage.getItem(SESSION_KEY);
  if (existing) return existing;
  const next = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  window.sessionStorage.setItem(SESSION_KEY, next);
  return next;
}

export function LiveVisitorTracker() {
  const pathname = usePathname();
  const searchParams = useSearchParams();

  useEffect(() => {
    let cancelled = false;
    const sessionId = getSessionId();

    async function sendHeartbeat() {
      if (cancelled || document.visibilityState === "hidden") return;
      const query = searchParams?.toString();
      const path = `${pathname || "/"}${query ? `?${query}` : ""}`;
      await fetch("/api/analytics/heartbeat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId,
          path,
          url: window.location.href,
          title: document.title,
          referrer: document.referrer
        }),
        keepalive: true
      }).catch(() => undefined);
    }

    sendHeartbeat();
    const timer = window.setInterval(sendHeartbeat, 20_000);
    const onVisibilityChange = () => sendHeartbeat();
    document.addEventListener("visibilitychange", onVisibilityChange);

    return () => {
      cancelled = true;
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", onVisibilityChange);
    };
  }, [pathname, searchParams]);

  return null;
}
