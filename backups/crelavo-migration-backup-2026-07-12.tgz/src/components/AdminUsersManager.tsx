"use client";

import { useEffect, useMemo, useState } from "react";
import { adminApiHeaders, getStoredAdminApiToken } from "@/lib/admin-client-auth";
import { supabaseBrowser } from "@/lib/supabase";

type LegalAcceptance = {
  id: string;
  production_id?: string | null;
  version: string;
  accepted_at?: string | null;
  ip_address?: string | null;
  user_agent?: string | null;
  production_type?: string | null;
  package_id?: string | null;
  title?: string | null;
  responsibility_text?: string | null;
  rights_warranty_text?: string | null;
};

type AdminUser = {
  id: string;
  name: string;
  email: string;
  ip: string;
  country: string;
  city: string;
  role?: string;
  provider?: string;
  email_confirmed?: boolean;
  created_at?: string | null;
  last_sign_in_at?: string | null;
  credits: number;
  reserved?: number;
  available?: number;
  value: string;
  legal_acceptance_count?: number;
  latest_legal_acceptance?: LegalAcceptance | null;
  banned_until?: string | null;
};

const fallbackUsers: AdminUser[] = [
  { id: "usr_001", name: "Demo User", email: "demo@cliporastudio.ai", ip: "192.168.1.24", country: "Turkey", city: "Istanbul", credits: 2500, reserved: 0, available: 2500, value: "$29" },
  { id: "usr_002", name: "Agency Account", email: "agency@example.com", ip: "88.240.10.42", country: "Turkey", city: "Ankara", credits: 18000, reserved: 0, available: 18000, value: "$149" },
  { id: "usr_003", name: "Brand User", email: "brand@example.com", ip: "31.155.70.18", country: "Germany", city: "Berlin", credits: 6000, reserved: 0, available: 6000, value: "$59" }
];

export function AdminUsersManager() {
  const [users, setUsers] = useState<AdminUser[]>(fallbackUsers);
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState(fallbackUsers[0].id);
  const [creditAmount, setCreditAmount] = useState("500");
  const [banHours, setBanHours] = useState("24");
  const [note, setNote] = useState("Manual admin adjustment");
  const [adminEmail, setAdminEmail] = useState("");
  const [message, setMessage] = useState("Sample data is shown. Live data loads when an admin is signed in.");
  const [loading, setLoading] = useState(false);

  async function loadUsers() {
    setLoading(true);
    const { data: userData } = await supabaseBrowser().auth.getUser();
    const email = userData.user?.email ?? "";
    const token = getStoredAdminApiToken();
    setAdminEmail(email);
    if (!email) {
      setLoading(false);
      setMessage("No admin session found. Sample data is shown.");
      return;
    }

    const response = await fetch("/api/admin/users", { headers: adminApiHeaders(email, token) });
    const data = await response.json().catch(() => ({}));
    setLoading(false);

    if (!response.ok || !Array.isArray(data.users)) {
      setMessage(data.error ?? "Live users could not be loaded. Sample data is shown.");
      return;
    }

    setUsers(data.users);
    setSelectedId(data.users[0]?.id ?? "");
    setMessage(`${data.users.length} users loaded.`);
  }

  useEffect(() => {
    loadUsers();
  }, []);

  const filteredUsers = useMemo(() => {
    const clean = query.toLowerCase().trim();
    if (!clean) return users;
    return users.filter((user) =>
      user.id.toLowerCase().includes(clean) ||
      user.name.toLowerCase().includes(clean) ||
      user.email.toLowerCase().includes(clean) ||
      user.ip.toLowerCase().includes(clean)
    );
  }, [query, users]);

  const selectedUser = users.find((user) => user.id === selectedId) ?? filteredUsers[0] ?? users[0];
  const latestLegal = selectedUser?.latest_legal_acceptance ?? null;

  async function runUserAction(action: "delete_user" | "suspend_user" | "timed_ip_ban" | "unsuspend_user") {
    if (!selectedUser) return;
    if (!adminEmail) {
      setMessage("Admin email was not found. Sign in with an admin account.");
      return;
    }
    if (action === "delete_user" && !window.confirm(`Delete ${selectedUser.email}? This cannot be undone.`)) return;

    setLoading(true);
    const adminToken = getStoredAdminApiToken();
    const response = await fetch("/api/admin/users", {
      method: "POST",
      headers: adminApiHeaders(adminEmail, adminToken, { "Content-Type": "application/json" }),
      body: JSON.stringify({ user_id: selectedUser.id, action, ban_hours: Number(banHours), note })
    });
    const data = await response.json().catch(() => ({}));
    setLoading(false);

    if (!response.ok) {
      setMessage(data.error ?? "User admin action failed.");
      return;
    }

    setMessage(data.message ?? "User admin action completed.");
    await loadUsers();
  }

  async function adjustCredits(action: "add" | "remove") {
    if (!selectedUser) return;
    if (!adminEmail) {
      setMessage("Admin email was not found. Sign in with an admin account.");
      return;
    }

    setLoading(true);
    const adminToken = getStoredAdminApiToken();
    const response = await fetch("/api/admin/credits", {
      method: "POST",
      headers: adminApiHeaders(adminEmail, adminToken, { "Content-Type": "application/json" }),
      body: JSON.stringify({ email: selectedUser.email, amount: Number(creditAmount), action, note })
    });
    const data = await response.json().catch(() => ({}));
    setLoading(false);

    if (!response.ok) {
      setMessage(data.error ?? "Credit operation failed.");
      return;
    }

    setMessage(action === "add" ? "Credits were added successfully." : "Credits were removed successfully.");
    await loadUsers();
  }

  if (!selectedUser) return <p className="form-message">User not found.</p>;

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <section className="card admin-wide-card">
        <h2>Search members</h2>
        <p style={{ color: "var(--muted)" }}>Find members by name, surname, email, ID or IP address.</p>
        <div className="field">
          <label>Search</label>
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Enter name, user ID, email or IP..." />
        </div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <button className="btn secondary" type="button" onClick={loadUsers} disabled={loading}>{loading ? "Loading..." : "Refresh live data"}</button>
          {message ? <span className="badge">{message}</span> : null}
        </div>
      </section>

      <section className="card admin-wide-card">
        <h2>Member list</h2>
        <div className="admin-table-wrap">
          <table className="table">
            <thead>
              <tr><th>ID</th><th>Full name</th><th>Email</th><th>IP / country</th><th>Provider</th><th>Email status</th><th>Created at</th><th>Last sign-in</th><th>Credits</th><th>Value</th><th>Action</th></tr>
            </thead>
            <tbody>
              {filteredUsers.map((user) => (
                <tr key={user.email}>
                  <td className="admin-user-id-cell"><code>{user.id}</code></td>
                  <td>{user.name}</td>
                  <td className="admin-email-cell">{user.email}</td>
                  <td>{user.ip}<br /><small>{user.city}, {user.country}</small></td>
                  <td>{user.provider ?? "email"}</td>
                  <td>{user.banned_until ? "Suspended" : user.email_confirmed ? "Confirmed" : "Pending"}</td>
                  <td>{user.created_at ? new Date(user.created_at).toLocaleDateString() : "-"}</td>
                  <td>{user.last_sign_in_at ? new Date(user.last_sign_in_at).toLocaleDateString() : "-"}</td>
                  <td>{user.credits.toLocaleString()}</td>
                  <td>{user.value}</td>
                  <td className="admin-table-actions"><button className="btn" type="button" onClick={() => setSelectedId(user.id)}>Select</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="card selected-billing-card">
        <span className="badge">Selected user</span>
        <h2>{selectedUser.name}</h2>
        <p>{selectedUser.email} • {selectedUser.ip} • {selectedUser.city}, {selectedUser.country}</p>
        <div className="admin-info-grid">
          <div><span>User ID</span><strong className="admin-long-id">{selectedUser.id}</strong><small>Supabase user id</small></div>
          <div><span>Account status</span><strong>{selectedUser.banned_until ? "Suspended" : "Active"}</strong><small>{selectedUser.banned_until ? `Until ${new Date(selectedUser.banned_until).toLocaleString()}` : "No active admin ban"}</small></div>
          <div><span>Total credits</span><strong>{selectedUser.credits.toLocaleString()}</strong><small>Credit balance</small></div>
          <div><span>Reserved credits</span><strong>{(selectedUser.reserved ?? 0).toLocaleString()}</strong><small>Active requests</small></div>
          <div><span>Available</span><strong>{(selectedUser.available ?? selectedUser.credits).toLocaleString()}</strong><small>{selectedUser.value}</small></div>
          <div><span>Legal acceptance</span><strong>{selectedUser.legal_acceptance_count ?? 0}</strong><small>{latestLegal ? `Latest ${latestLegal.version}` : "No accepted production terms"}</small></div>
        </div>

        <div className="dynamic-brief-panel" style={{ marginTop: 14 }}>
          <span className="badge">Legal Acceptance Records</span>
          <h3>Production liability acceptance</h3>
          {latestLegal ? (
            <div style={{ display: "grid", gap: 10 }}>
              <p style={{ color: "var(--muted)", margin: 0 }}>This user accepted the English responsibility text before starting production. Admin sees this record for production and user review.</p>
              <div className="admin-info-grid">
                <div><span>Acceptance ID</span><strong>{latestLegal.id}</strong><small>Version {latestLegal.version}</small></div>
                <div><span>Accepted at</span><strong>{latestLegal.accepted_at ? new Date(latestLegal.accepted_at).toLocaleString() : "Recorded"}</strong><small>{latestLegal.ip_address ?? "IP not captured"}</small></div>
                <div><span>Production</span><strong>{latestLegal.title ?? "Untitled"}</strong><small>{latestLegal.production_id ?? "No production id"}</small></div>
                <div><span>Package</span><strong>{latestLegal.package_id ?? "-"}</strong><small>{latestLegal.production_type ?? "-"}</small></div>
              </div>
              <div style={{ maxHeight: 180, overflowY: "auto", padding: 12, border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12, background: "rgba(2,6,23,0.36)", color: "#cbd5e1", fontSize: 12, lineHeight: 1.5 }}>
                <p style={{ marginTop: 0 }}>{latestLegal.responsibility_text}</p>
                <p>{latestLegal.rights_warranty_text}</p>
                {latestLegal.user_agent ? <p style={{ marginBottom: 0 }}>User agent: {latestLegal.user_agent}</p> : null}
              </div>
            </div>
          ) : (
            <p style={{ color: "var(--muted)", margin: 0 }}>No production responsibility acceptance exists for this user yet.</p>
          )}
        </div>

        <div className="admin-production-editor">
          <div className="field"><label>Credit amount</label><input value={creditAmount} onChange={(event) => setCreditAmount(event.target.value)} /></div>
          <div className="field"><label>Ban duration, hours</label><input value={banHours} onChange={(event) => setBanHours(event.target.value)} /></div>
          <div className="field"><label>Operation note</label><input value={note} onChange={(event) => setNote(event.target.value)} /></div>
        </div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <button className="btn" type="button" disabled={loading} onClick={() => adjustCredits("add")}>Add credits</button>
          <button className="btn secondary" type="button" disabled={loading} onClick={() => adjustCredits("remove")}>Remove credits</button>
          <button className="btn secondary" type="button" disabled={loading} onClick={() => runUserAction("suspend_user")}>Suspend user</button>
          <button className="btn secondary" type="button" disabled={loading} onClick={() => runUserAction("timed_ip_ban")}>Timed IP/user ban</button>
          <button className="btn secondary" type="button" disabled={loading} onClick={() => runUserAction("unsuspend_user")}>Unblock user</button>
          <button className="btn danger" type="button" disabled={loading} onClick={() => runUserAction("delete_user")}>Delete user</button>
        </div>
      </section>
    </div>
  );
}
