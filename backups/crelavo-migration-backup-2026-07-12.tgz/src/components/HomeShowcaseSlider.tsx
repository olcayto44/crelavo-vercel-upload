import { HardReloadLink } from "@/components/HardReloadLink";

export type HomeShowcaseSlide = {
  title: string;
  kicker: string;
  description: string;
  href: string;
  tone: "cyan" | "purple" | "green" | "amber" | "pink" | "blue";
  imageUrl?: string;
};

export function HomeShowcaseSlider({ title, subtitle, slides, reverse = false }: { title: string; subtitle: string; slides: HomeShowcaseSlide[]; reverse?: boolean }) {
  const loopSlides = [...slides, ...slides];
  return (
    <section className="container section home-section-tight clean-feed-section showcase-slider-section">
      <div className="showcase-slider-head">
        <div>
          <span className="badge">Showcase</span>
          <h2>{title}</h2>
          <p className="section-lead">{subtitle}</p>
        </div>
      </div>
      <div className={`showcase-slider-track-wrap ${reverse ? "reverse" : ""}`}>
        <div className="showcase-slider-track">
          {loopSlides.map((slide, index) => (
            <HardReloadLink className={`showcase-slide-card tone-${slide.tone}`} href={slide.href} key={`${slide.title}-${index}`}>
              <div className="showcase-art" style={slide.imageUrl ? { backgroundImage: `linear-gradient(180deg, transparent 12%, rgba(2, 6, 23, .82)), url(${slide.imageUrl})` } : undefined} />
              <span>{slide.kicker}</span>
              <strong>{slide.title}</strong>
              <p>{slide.description}</p>
            </HardReloadLink>
          ))}
        </div>
      </div>
    </section>
  );
}
