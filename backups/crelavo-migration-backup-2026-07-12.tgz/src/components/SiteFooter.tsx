import Link from "next/link";
import { FooterHelpDrawer } from "@/components/FooterHelpDrawer";
import { HardReloadLink } from "@/components/HardReloadLink";
import { footerGroups } from "@/lib/site-content";
import { getConfiguredSiteContentConfig } from "@/lib/site-content-loader";

export async function SiteFooter() {
  const siteContent = await getConfiguredSiteContentConfig();
  const activeSocialLinks = siteContent.socialLinks.filter((link) => link.active);
  return (
    <footer className="container footer clean-feed-section site-footer">
      <section className="footer-seo-panel" aria-label="Clipora Studio AI production overview">
        <span className="badge">AI production studio</span>
        <h2>Websites, apps, e-commerce campaigns and AI video production in one managed studio.</h2>
        <p aria-label="Clipora Studio is built for founders, agencies, creators, e-commerce sellers and teams">
          <Link className="footer-seo-link" href="/">Clipora Studio</Link> is built for founders, agencies, creators, e-commerce sellers and teams that need production-ready digital assets without managing separate tools for strategy, design, video, copy, voice, editing, delivery and publishing. The platform combines an <Link className="footer-seo-link" href="/dashboard/assistant-workspace">AI production studio</Link> workspace with category-specific workflows for <Link className="footer-seo-link" href="/products/website">AI website production</Link>, landing pages, <Link className="footer-seo-link" href="/products/mobile-app">mobile app screens</Link>, <Link className="footer-seo-link" href="/products/saas">SaaS</Link> dashboards, <Link className="footer-seo-link" href="/products/admin-panel">admin panels</Link>, product launch pages and managed delivery. A team can begin with a brand idea, product link, campaign brief, app request or website plan; Clipora turns that input into a structured production request, reserves credits, routes the work through the right automation path and keeps final files organized in the dashboard.
        </p>
        <p>
          For e-commerce teams, <Link className="footer-seo-link" href="/">Clipora Studio</Link> supports product-link-first production. A <Link className="footer-seo-link" href="/products/product-ad-video">Shopify</Link>, <Link className="footer-seo-link" href="/products/product-ad-video">Amazon</Link>, <Link className="footer-seo-link" href="/products/product-ad-video">Trendyol</Link>, WooCommerce or direct product URL can become a product link to ad video workflow, short-form social campaign, product visual set, marketplace listing concept, store banner, SEO product description, caption set and publishing-ready campaign package. The same system can prepare <Link className="footer-seo-link" href="/products/text-to-campaign">Text-to-Campaign</Link> briefs, <Link className="footer-seo-link" href="/products/social-campaign-video">social campaign videos</Link>, UGC ad angles, product benefit scripts and conversion-focused creative directions without making the user jump between unrelated generators.
        </p>
        <p>
          For media creators and agencies, the platform covers <Link className="footer-seo-link" href="/products/ai-video-generator">AI video</Link>, <Link className="footer-seo-link" href="/products/text-to-video">text-to-video</Link>, <Link className="footer-seo-link" href="/products/image-to-video">image-to-video</Link>, script-to-video planning, <Link className="footer-seo-link" href="/products/voice-over">voice-over</Link>, subtitles, <Link className="footer-seo-link" href="/products/music-video-mv">music videos</Link>, <Link className="footer-seo-link" href="/products/long-film-series-clipping">long video clips</Link>, <Link className="footer-seo-link" href="/products/cinematic-video">cinematic scenes</Link>, <Link className="footer-seo-link" href="/products/animation">animations</Link>, <Link className="footer-seo-link" href="/products/avatar">avatar videos</Link>, self-in-video scenes, multi-person talking videos, <Link className="footer-seo-link" href="/products/global-localization">regional clothing</Link>, local environment direction, local accent or dialect voice options, <Link className="footer-seo-link" href="/products/lip-sync">lip synchronization</Link>, <Link className="footer-seo-link" href="/products/voice-clone">voice cloning</Link> and <Link className="footer-seo-link" href="/products/visual-clone">visual cloning</Link>. These workflows help a creator move from raw idea to usable production plan, from production plan to provider job, and from provider job to organized delivery.
        </p>
        <p>
          Business and brand teams can also use <Link className="footer-seo-link" href="/">Clipora Studio</Link> for <Link className="footer-seo-link" href="/products/brand-kit">brand kits</Link>, <Link className="footer-seo-link" href="/products/visual-image-pack">visual packages</Link>, pitch decks, document packs, <Link className="footer-seo-link" href="/products/saas">SaaS screens</Link>, admin dashboards, marketplace campaign assets and localized launch materials. A startup can request a website today, then return for a mobile app, product video, AI avatar, social campaign, image pack, multilingual ad or sales PDF tomorrow. This makes Clipora broader than a single AI video generator and more operational than a design template site: it is a managed AI creative production studio for useful deliverables.
        </p>
        <p>
          The core SEO focus of <Link className="footer-seo-link" href="/">Clipora Studio</Link> is clear and intentionally wide: AI production studio, AI website production, AI app production, <Link className="footer-seo-link" href="/products/product-ad-video">AI e-commerce campaign generator</Link>, Shopify product link ad video, Amazon product campaign, Trendyol product video, product link to ad video, <Link className="footer-seo-link" href="/products/text-to-campaign">AI marketing campaigns</Link>, AI video ads, AI avatar video, AI voice-over, AI image generation, brand kit production, visual package delivery and <Link className="footer-seo-link" href="/products/categories">managed creative delivery</Link>. The goal is to explain the platform honestly to users and search engines: ideas, product links, scripts, images, brands and business requests can all become trackable production workflows.
        </p>
      </section>

      <div className="site-footer-grid">
        {footerGroups.filter((group) => group.title !== "Company and Help").map((group) => (
          <div className="site-footer-group" key={group.title}>
            <h3>{group.title}</h3>
            <nav>
              {group.links.map((link) => <Link href={link.href} key={`${group.title}-${link.label}`}>{link.label}</Link>)}
            </nav>
          </div>
        ))}
        {activeSocialLinks.length ? (
          <div className="site-footer-group footer-social-group">
            <h3>Social</h3>
            <nav className="footer-social-links" aria-label="Clipora Studio social links">
              {activeSocialLinks.map((link) => <a href={link.href} key={`${link.label}-${link.href}`} target="_blank" rel="noreferrer">{link.label}</a>)}
            </nav>
          </div>
        ) : null}
        <FooterHelpDrawer panels={siteContent.footerHelpPanels} />
        <div className="site-footer-brand footer-brand-bottom-right">
          <Link href="/" className="site-footer-brand-link"><strong>Clipora Studio</strong></Link>
          <p className="site-footer-description clean-footer-copy" aria-label="Global AI production studio for websites, mobile apps, e-commerce product campaigns, Shopify product link ads, Amazon product campaigns and Trendyol product videos">Global AI production studio for websites, mobile apps, e-commerce product campaigns, Shopify/Amazon/Trendyol product links, ad videos, avatars, visuals, voice-over and managed creative delivery.</p>
          <div className="footer-commerce-shortcuts" aria-label="E-commerce campaign shortcuts">
            <Link href="/dashboard/assistant-workspace?idea=Shopify%20product%20link%20ad&category=campaign&mode=commerce">Shopify campaign</Link>
            <Link href="/dashboard/assistant-workspace?idea=Amazon%20product%20campaign&category=campaign&mode=commerce">Amazon campaign</Link>
            <Link href="/dashboard/assistant-workspace?idea=Trendyol%20product%20video&category=campaign&mode=commerce">Trendyol video</Link>
            <Link href="/dashboard/assistant-workspace?idea=Product%20link%20to%20ad%20video&category=campaign&mode=commerce">Product link ad</Link>
          </div>
        </div>
      </div>

      <div className="site-footer-bottom">
        <span>Copyright © 2026 Clipora Studio. All rights reserved.</span>
        <span>Websites, apps, e-commerce campaigns, AI video, managed delivery, credits and automation in one platform.</span>
      </div>
    </footer>
  );
}
