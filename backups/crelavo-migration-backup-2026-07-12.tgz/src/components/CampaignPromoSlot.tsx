import { CampaignPromoClient } from "@/components/CampaignPromoClient";
import { getConfiguredAdSlots } from "@/lib/ad-config";

type CampaignPromoPayload = {
  eyebrow?: string;
  title?: string;
  body?: string;
  cta?: string;
  href?: string;
  endsAt?: string;
};

function parsePromoPayload(code: string): Required<CampaignPromoPayload> | null {
  try {
    const value = JSON.parse(code) as CampaignPromoPayload;
    return {
      eyebrow: String(value.eyebrow || "Limited campaign"),
      title: String(value.title || "Launch credit sale"),
      body: String(value.body || "Use this promo slot for package discounts, launch offers and limited credit campaigns."),
      cta: String(value.cta || "View packages"),
      href: String(value.href || "/pricing"),
      endsAt: String(value.endsAt || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString())
    };
  } catch {
    return null;
  }
}

export async function CampaignPromoSlot() {
  const slots = await getConfiguredAdSlots();
  const slot = slots.find((item) => item.id === "campaign-promo" && item.status === "active" && item.code.trim());
  if (!slot) return null;

  const payload = parsePromoPayload(slot.code);
  if (!payload) return null;

  return <CampaignPromoClient {...payload} />;
}
