"use client";

import { useEffect, useMemo, useState, type MouseEvent } from "react";
import Link from "next/link";
import { Heart, PlayCircle } from "lucide-react";
import type { SampleVideo } from "@/lib/sample-videos";
import { sampleVideos } from "@/lib/sample-videos";

type SampleVideoGalleryProps = {
  title?: string;
  subtitle?: string;
  limit?: number;
  category?: string;
  videos?: SampleVideo[];
  shuffleOnLoad?: boolean;
};

function shuffleSamples(items: SampleVideo[]) {
  const shuffled = [...items];
  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex], shuffled[index]];
  }
  return shuffled;
}

function sampleLikeCount(item: SampleVideo) {
  return 120 + Array.from(item.id).reduce((total, char) => total + char.charCodeAt(0), 0) % 880;
}

function playPreview(event: MouseEvent<HTMLAnchorElement>) {
  const video = event.currentTarget.querySelector("video");
  video?.play().catch(() => undefined);
}

function pausePreview(event: MouseEvent<HTMLAnchorElement>) {
  const video = event.currentTarget.querySelector("video");
  if (!video) return;
  video.pause();
  video.currentTime = 0;
}

export function SampleVideoGallery({ title = "Sample video outputs", subtitle = "Demo video cards show users what can be produced. Real MP4 preview URLs can be connected from the admin panel.", limit, category, videos = sampleVideos, shuffleOnLoad = false }: SampleVideoGalleryProps) {
  const baseItems = useMemo(() => {
    const filtered = category ? videos.filter((item) => item.category.toLowerCase().includes(category.toLowerCase())) : videos;
    return typeof limit === "number" ? filtered.slice(0, limit) : filtered;
  }, [category, limit, videos]);
  const [items, setItems] = useState<SampleVideo[]>(baseItems);

  useEffect(() => {
    setItems(shuffleOnLoad ? shuffleSamples(baseItems) : baseItems);
  }, [baseItems, shuffleOnLoad]);

  return (
    <section className="sample-video-section">
      <div className="sample-video-head">
        <div>
          <span className="badge"><PlayCircle size={15} /> Sample outputs</span>
          <h2>{title}</h2>
          <p className="section-lead">{subtitle}</p>
        </div>
        <Link className="btn secondary" href="/categories">View all categories</Link>
      </div>
      <div className="sample-video-grid sample-video-grid-cinematic">
        {items.map((item) => (
          <Link className="sample-video-card sample-video-card-cinematic" href={`/samples/${item.id}`} key={item.id} onMouseEnter={playPreview} onMouseLeave={pausePreview}>
            <div className="sample-video-preview sample-video-preview-cinematic">
              {item.videoUrl ? <video className="sample-card-video" src={item.videoUrl} muted loop playsInline preload="metadata" /> : null}
              <span className="sample-video-play"><PlayCircle size={34} /></span>
              <small>{item.category}</small>
              <strong>{item.title}</strong>
              <span className="sample-card-like"><Heart size={15} /> {sampleLikeCount(item).toLocaleString()}</span>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
