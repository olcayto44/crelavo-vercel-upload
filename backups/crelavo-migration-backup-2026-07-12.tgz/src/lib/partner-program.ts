export const partnerCommissionDefaults = {
  plannedRange: "variable 15-40% commission by package margin",
  defaultDraftPercent: 35,
  payoutProvider: "Stripe affiliate ledger or Lemon Squeezy affiliate",
  launchMode: "early_access",
  payoutSchedule: "Affiliate earnings are collected from Monday 00:00 through Sunday 23:59. Approved commissions are reviewed Sunday night after 24:00 cutoff and paid every Monday.",
  payoutCutoff: "Sunday 23:59 weekly cutoff",
  payoutDay: "Monday weekly payout"
};

export const partnerPackageCommissionRules = [
  {
    packageGroup: "Low-cost digital credit plans",
    examplePackages: ["Starter monthly", "Creator Top-up", "Business monthly"],
    marginProfile: "low-to-medium provider cost",
    defaultPercent: 25,
    note: "Lower ticket or provider-cost-sensitive products should not use the highest commission rate."
  },
  {
    packageGroup: "Standard production subscriptions",
    examplePackages: ["Pro monthly", "Ultra monthly", "AI video / website production packages"],
    marginProfile: "balanced margin",
    defaultPercent: 30,
    note: "Default partner rate for normal paid plans where delivery cost is predictable."
  },
  {
    packageGroup: "Growth Intelligence service plans",
    examplePackages: ["Starter Intelligence Agent", "Growth Intelligence Agent", "Enterprise Intelligence Agent"],
    marginProfile: "higher recurring service value",
    defaultPercent: 35,
    note: "Strong affiliate product because recurring service value is high and provider cost can be controlled."
  },
  {
    packageGroup: "High-cost managed delivery / custom production",
    examplePackages: ["Custom app", "managed SaaS build", "heavy provider/API usage", "enterprise custom work"],
    marginProfile: "high labor or provider cost",
    defaultPercent: 15,
    note: "High delivery-cost packages need lower commission or manual approval to protect margin."
  }
];

export const partnerAudienceSegments = [
  "AI tool reviewers",
  "No-code educators",
  "TikTok AI creators",
  "YouTube Shorts creators",
  "SaaS and startup creators",
  "Ecommerce growth creators",
  "Agency owners and consultants"
];

export const partnerAssets = [
  {
    title: "Creator referral link",
    status: "API-ready placeholder",
    detail: "Each approved partner will receive a unique referral code/link once tracking is connected."
  },
  {
    title: "Launch video angles",
    status: "Prepared",
    detail: "Suggested hooks focus on AI production, no-code delivery, websites, apps, video ads and client-ready ZIP/source packages."
  },
  {
    title: "Commission terms",
    status: "Waiting for final percent",
    detail: "The structure is ready; final public percent is set when payout/API provider is selected."
  },
  {
    title: "Partner review workflow",
    status: "Prepared",
    detail: "Applications can move through pending, contacted, approved, rejected and live states."
  }
];

export const partnerWorkflowStages = [
  "Application received",
  "Channel reviewed",
  "Partner approved",
  "Referral code and sharing links assigned",
  "Content brief sent",
  "First signup tracked",
  "First paid conversion tracked",
  "Commission/payout reviewed"
];

export const partnerReadinessChecks = [
  {
    label: "Public landing page",
    status: "ready",
    note: "Partner Program page explains who it is for and collects early access applications."
  },
  {
    label: "User dashboard entry",
    status: "ready",
    note: "Dashboard has a Partner Rewards area for referral status, assets and future links."
  },
  {
    label: "Admin review workflow",
    status: "ready",
    note: "Admin panel has statuses, sample application fields, launch checklist and provider blockers."
  },
  {
    label: "Commission percent",
    status: "pending_final_decision",
    note: "Draft range is prepared; final percent is selected before launch."
  },
  {
    label: "Payout/tracking provider",
    status: "pending_api",
    note: "Stripe custom referral or Lemon Squeezy affiliate can be connected later."
  },
  {
    label: "Live payout start",
    status: "pending_api",
    note: "Start only after payment provider, attribution and payout rules are tested."
  }
];

export const partnerApplicationFields = [
  "Full name",
  "Email",
  "Channel type",
  "Channel URL",
  "Audience size",
  "Main audience",
  "Promotion idea",
  "Application IP address",
  "Application country",
  "Application city",
  "Payout email later",
  "Payout method after approval",
  "Bank account holder after approval",
  "Bank name after approval",
  "IBAN / SWIFT after approval",
  "Payout detail change request email log",
  "Status",
  "Referral code later"
];

export const samplePartnerApplications = [
  {
    name: "AI Tools Reviewer",
    email: "aitools-reviewer@example.com",
    channel: "YouTube Shorts",
    channelUrl: "https://youtube.com/@aitoolsreviewer",
    audience: "AI tools and no-code founders",
    audienceSize: "38k subscribers",
    status: "pending",
    submittedAt: "2026-07-08 10:15",
    ip: "185.60.216.35",
    country: "Turkey",
    city: "Istanbul",
    inbox: "affiliate",
    nextAction: "Review channel fit, then approve or reject with one-click email."
  },
  {
    name: "No-Code Builder Creator",
    email: "nocode-builder@example.com",
    channel: "TikTok",
    channelUrl: "https://tiktok.com/@nocodebuilder",
    audience: "SaaS builders, freelancers and agencies",
    audienceSize: "64k followers",
    status: "contacted",
    submittedAt: "2026-07-07 15:40",
    ip: "31.145.82.19",
    country: "Turkey",
    city: "Izmir",
    inbox: "affiliate",
    nextAction: "Send launch asset pack after commission percent is finalized."
  },
  {
    name: "Agency Growth Partner",
    email: "agency-growth@example.com",
    channel: "LinkedIn / newsletter",
    channelUrl: "https://linkedin.com/company/agency-growth-partner",
    audience: "Digital agency owners and ecommerce operators",
    audienceSize: "12k newsletter subscribers",
    status: "approved_pending_code",
    submittedAt: "2026-07-06 09:20",
    ip: "88.255.101.74",
    country: "Turkey",
    city: "Ankara",
    inbox: "affiliate",
    nextAction: "Assign referral code when tracking provider is connected."
  }
];

export const partnerInboxRoutingRules = [
  { source: "Partner application form", destination: "Admin → Partner Program", note: "Affiliate/partner applications and replies should be kept in the partner inbox, not the normal customer support queue." },
  { source: "Partner payout or IBAN email", destination: "Admin → Partner Program + Finance", note: "Bank detail changes require finance verification before Monday payout." },
  { source: "Normal customer contact", destination: "Admin → Contact / support flow", note: "General member support, production requests and user replies stay outside the affiliate inbox." }
];

export const partnerLaunchSequence = [
  { phase: "Before public partner push", action: "Keep /affiliate collecting early applications, but avoid public payout promises until commission percent and payout provider are final." },
  { phase: "Payment Link launch", action: "If a referred user pays through Payment Link, track partner/source manually and activate user credits from /admin/credits after Stripe receipt review." },
  { phase: "First creator tests", action: "Start with TikTok and YouTube Shorts creators who can demonstrate website/app/video package use cases." },
  { phase: "After Stripe/API setup", action: "Connect paid attribution, commission ledger, payout approvals and partner-specific links." },
  { phase: "Scale partners", action: "Only scale after referral-to-signup-to-paid conversion is verified with one complete manual E2E path." }
];

export const partnerChannelPriority = [
  { channel: "TikTok AI creators", priority: "Primary", reason: "Short before/after demos and free-tool-to-production flow can convert quickly." },
  { channel: "YouTube Shorts creators", priority: "Primary", reason: "Best for repeatable AI production, no-code and ecommerce workflow demos." },
  { channel: "No-code educators", priority: "Primary", reason: "Strong fit for websites, apps, source ZIP and client-ready delivery packages." },
  { channel: "Ecommerce growth creators", priority: "Secondary", reason: "Good for product-link ad videos and store assets after provider examples are stable." },
  { channel: "Agency/newsletter partners", priority: "Secondary", reason: "Higher-ticket potential, but needs trust assets and clean case studies." }
];

export const partnerLaunchChecklist = [
  "Choose final commission percent before public payout promise",
  "Select Stripe custom referral ledger or Lemon Squeezy affiliate provider",
  "Add affiliate/referral tracking table or provider webhook mapping",
  "Generate unique partner referral links",
  "Prepare creator asset pack: hooks, demo script, screenshots, offer copy",
  "Add payout approval statuses in admin after payment provider is live",
  "Run one manual test: click link → signup → first production → paid conversion → commission record"
];

export const partnerCommissionTiers = [
  {
    id: "starter_creator",
    label: "Starter creator",
    followerRange: "1k-10k followers",
    channels: ["TikTok", "YouTube Shorts", "X / LinkedIn"],
    defaultPercent: 25,
    approvalRule: "Good audience fit, but early or small channel."
  },
  {
    id: "growth_creator",
    label: "Growth creator",
    followerRange: "10k-50k followers",
    channels: ["TikTok", "YouTube Shorts", "Blog / newsletter"],
    defaultPercent: 30,
    approvalRule: "Consistent AI/no-code content and reliable engagement."
  },
  {
    id: "premium_creator",
    label: "Premium creator",
    followerRange: "50k-250k followers",
    channels: ["TikTok", "YouTube", "Newsletter", "Community"],
    defaultPercent: 35,
    approvalRule: "Strong conversion potential, clear audience trust and launch video capability."
  },
  {
    id: "strategic_partner",
    label: "Strategic partner",
    followerRange: "250k+ followers or agency network",
    channels: ["YouTube", "Agency", "Community", "Newsletter"],
    defaultPercent: 40,
    approvalRule: "High-value creator, agency, community owner or distribution partner."
  }
];

export const partnerStatusCommissionAdjustments = [
  { status: "pending", label: "Pending review", adjustment: 0, note: "Application received; no public payout terms yet." },
  { status: "contacted", label: "Contacted", adjustment: 0, note: "Channel fit being reviewed." },
  { status: "approved", label: "Approved", adjustment: 0, note: "Default tier commission can apply." },
  { status: "top_performer", label: "Top performer", adjustment: 5, note: "Optional bonus for partners with proven paid conversions." },
  { status: "paused", label: "Paused", adjustment: -100, note: "No new commission accrual while paused." }
];

export const partnerPaymentProfiles = [
  {
    partnerCode: "CLIPORA-AITOOLS",
    partner: "AI Tools Reviewer",
    email: "aitools-reviewer@example.com",
    payoutMethod: "Bank transfer",
    accountHolder: "AI Tools Reviewer Media LLC",
    bankName: "Wise Business",
    iban: "TR00 0000 0000 0000 0000 0000 01",
    swift: "TRWIBEB1XXX",
    country: "TR",
    lastIp: "185.60.216.35",
    lastCountry: "Turkey",
    lastCity: "Istanbul",
    status: "pending_verification",
    lastUpdated: "2026-07-02",
    changePolicy: "Partner must email finance before payout details are changed."
  },
  {
    partnerCode: "CLIPORA-NOCODE",
    partner: "No-Code Builder Creator",
    email: "nocode-builder@example.com",
    payoutMethod: "Bank transfer",
    accountHolder: "No-Code Builder Studio",
    bankName: "Revolut Business",
    iban: "TR00 0000 0000 0000 0000 0000 02",
    swift: "REVOLT21XXX",
    country: "TR",
    lastIp: "31.145.82.19",
    lastCountry: "Turkey",
    lastCity: "Izmir",
    status: "verified",
    lastUpdated: "2026-07-03",
    changePolicy: "Partner must email finance before payout details are changed."
  },
  {
    partnerCode: "CLIPORA-AGENCY",
    partner: "Agency Growth Partner",
    email: "agency-growth@example.com",
    payoutMethod: "Bank transfer",
    accountHolder: "Agency Growth Partner LTD",
    bankName: "Garanti BBVA",
    iban: "TR00 0000 0000 0000 0000 0000 03",
    swift: "TGBATRISXXX",
    country: "TR",
    lastIp: "88.255.101.74",
    lastCountry: "Turkey",
    lastCity: "Ankara",
    status: "verified",
    lastUpdated: "2026-07-08",
    changePolicy: "Partner must email finance before payout details are changed."
  }
];

export const partnerReferralLinks = [
  {
    partnerCode: "CLIPORA-AITOOLS",
    slug: "aitools",
    status: "ready_after_tracking",
    primaryPath: "/?ref=CLIPORA-AITOOLS",
    affiliatePath: "/affiliate?ref=CLIPORA-AITOOLS",
    growthIntelligencePath: "/growth-intelligence?ref=CLIPORA-AITOOLS&utm_source=affiliate&utm_medium=creator&utm_campaign=growth_intelligence",
    dashboardPath: "/dashboard/partners",
    shareText: "Try Clipora Studio for AI videos, websites, apps and Growth Intelligence. Use my partner link to start.",
    note: "Use this for AI tool review videos and free-tool conversion funnels."
  },
  {
    partnerCode: "CLIPORA-NOCODE",
    slug: "nocode",
    status: "ready_after_tracking",
    primaryPath: "/?ref=CLIPORA-NOCODE",
    affiliatePath: "/affiliate?ref=CLIPORA-NOCODE",
    growthIntelligencePath: "/growth-intelligence?ref=CLIPORA-NOCODE&utm_source=affiliate&utm_medium=tiktok&utm_campaign=growth_intelligence",
    dashboardPath: "/dashboard/partners",
    shareText: "Build production-ready AI assets, websites and growth campaigns with Clipora Studio. Start with my partner link.",
    note: "Use this for no-code tutorials, SaaS builder content and TikTok demos."
  },
  {
    partnerCode: "CLIPORA-AGENCY",
    slug: "agency",
    status: "ready_after_tracking",
    primaryPath: "/?ref=CLIPORA-AGENCY",
    affiliatePath: "/affiliate?ref=CLIPORA-AGENCY",
    growthIntelligencePath: "/growth-intelligence?ref=CLIPORA-AGENCY&utm_source=affiliate&utm_medium=agency&utm_campaign=growth_intelligence",
    dashboardPath: "/dashboard/partners",
    shareText: "Use Clipora Growth Intelligence to monitor public competitor signals and receive executive reports. Start with my partner link.",
    note: "Best for agencies, consultants and ecommerce growth partners promoting recurring service plans."
  }
];

export const partnerEmailCampaignTemplates = [
  { label: "Approval email", subject: "Your Clipora Partner Program application is approved", body: "Congratulations — your Clipora Partner Program application has been approved. Your partner account is now ready for referral setup. Please log in to your partner dashboard, review your referral reporting area and add/confirm your payout bank details before your first Monday payout. Affiliate earnings are collected from Monday 00:00 through Sunday 23:59 and approved commissions are paid every Monday after finance review." },
  { label: "Rejection email", subject: "Update about your Clipora Partner Program application", body: "Thank you for applying to the Clipora Partner Program. We reviewed your application carefully, but we are not able to approve it at this stage. We are sorry that we cannot move forward right now. As Clipora grows, we would be happy to review future applications again, and we hope to welcome you into the partner community later." },
  { label: "Bank info reminder", subject: "Add or confirm your affiliate payout bank details", body: "Please confirm your account holder name, bank name, IBAN/SWIFT and payout country in your partner dashboard. For security, payout details cannot be silently changed. If you need to update bank details later, reply to this email so finance can verify the update before the next Monday payout." },
  { label: "Weekly payout notice", subject: "Clipora affiliate payout review for this Monday", body: "Your weekly referred sales window has closed. Approved commissions from Monday 00:00 through Sunday 23:59 are under review for Monday payout. Please make sure your payout bank details are verified." }
];

export const partnerPerformanceSummary = [
  {
    partner: "AI Tools Reviewer",
    code: "CLIPORA-AITOOLS",
    channel: "YouTube Shorts",
    tier: "Growth creator",
    status: "approved",
    commissionPercent: 30,
    referredUsers: 18,
    payingUsers: 4,
    totalRevenueUsd: 316,
    estimatedCommissionUsd: 94.8,
    lastConversion: "Pro monthly",
    nextAction: "Assign live tracking link after payout provider setup."
  },
  {
    partner: "No-Code Builder Creator",
    code: "CLIPORA-NOCODE",
    channel: "TikTok",
    tier: "Premium creator",
    status: "top_performer",
    commissionPercent: 40,
    referredUsers: 64,
    payingUsers: 11,
    totalRevenueUsd: 1189,
    estimatedCommissionUsd: 475.6,
    lastConversion: "Business monthly",
    nextAction: "Keep higher rate if launch conversion data stays strong."
  },
  {
    partner: "Agency Growth Partner",
    code: "CLIPORA-AGENCY",
    channel: "LinkedIn / newsletter",
    tier: "Strategic partner",
    status: "approved",
    commissionPercent: 40,
    referredUsers: 10,
    payingUsers: 4,
    totalRevenueUsd: 1096,
    estimatedCommissionUsd: 413.45,
    lastConversion: "Growth Intelligence Agent monthly",
    nextAction: "Prepare agency-specific Growth Intelligence landing link and demo package."
  }
];

export const partnerReferredMembers = [
  {
    partnerCode: "CLIPORA-AGENCY",
    memberName: "Ahmet Yilmaz",
    memberEmail: "ahmet@example.com",
    signupDate: "2026-07-08",
    sourceChannel: "LinkedIn newsletter",
    status: "signed_up_no_purchase",
    purchasedPlan: "No package yet",
    packageCategory: "No purchase",
    purchaseAmountUsd: 0,
    commissionPercent: 0,
    commissionUsd: 0,
    payoutStatus: "no_commission_yet",
    period: "daily"
  },
  {
    partnerCode: "CLIPORA-AGENCY",
    memberName: "Growth Client",
    memberEmail: "growth-client@example.com",
    signupDate: "2026-07-07",
    sourceChannel: "Agency landing page",
    status: "paid",
    purchasedPlan: "Growth Intelligence Agent monthly",
    packageCategory: "Growth Intelligence",
    purchaseAmountUsd: 499,
    commissionPercent: 35,
    commissionUsd: 174.65,
    payoutStatus: "included_in_monday_payout_review",
    period: "weekly"
  },
  {
    partnerCode: "CLIPORA-AGENCY",
    memberName: "Agency Client",
    memberEmail: "agency-client@example.com",
    signupDate: "2026-07-04",
    sourceChannel: "Partner demo call",
    status: "paid",
    purchasedPlan: "Ultra monthly",
    packageCategory: "Standard subscription",
    purchaseAmountUsd: 199,
    commissionPercent: 30,
    commissionUsd: 59.7,
    payoutStatus: "pending_payout",
    period: "weekly"
  },
  {
    partnerCode: "CLIPORA-AGENCY",
    memberName: "Enterprise Buyer",
    memberEmail: "enterprise-buyer@example.com",
    signupDate: "2026-07-01",
    sourceChannel: "LinkedIn DM",
    status: "paid",
    purchasedPlan: "Enterprise Intelligence Agent monthly",
    packageCategory: "Growth Intelligence",
    purchaseAmountUsd: 1999,
    commissionPercent: 25,
    commissionUsd: 499.75,
    payoutStatus: "manual_margin_review",
    period: "monthly"
  }
];

export const partnerPayoutReportingWindows = [
  { label: "Daily", value: "daily", note: "Shows today’s signups, paid purchases and no-purchase referred members." },
  { label: "Weekly", value: "weekly", note: "Monday 00:00 through Sunday 23:59 commission window for Monday payout review." },
  { label: "Monthly", value: "monthly", note: "Aggregates partner revenue, package categories and commission liability for finance review." }
];

export const partnerPurchaseAttribution = [
  {
    partnerCode: "CLIPORA-AITOOLS",
    memberEmail: "founder-alpha@example.com",
    signupPlan: "Free / welcome credits",
    purchasedPlan: "Pro monthly",
    purchaseAmountUsd: 29,
    commissionPercent: 30,
    commissionUsd: 8.7,
    status: "pending_payout"
  },
  {
    partnerCode: "CLIPORA-NOCODE",
    memberEmail: "studio-owner@example.com",
    signupPlan: "Free / welcome credits",
    purchasedPlan: "Business monthly",
    purchaseAmountUsd: 79,
    commissionPercent: 40,
    commissionUsd: 31.6,
    status: "pending_payout"
  },
  {
    partnerCode: "CLIPORA-NOCODE",
    memberEmail: "ecom-team@example.com",
    signupPlan: "Free / welcome credits",
    purchasedPlan: "Creator Top-up",
    purchaseAmountUsd: 25,
    commissionPercent: 40,
    commissionUsd: 10,
    status: "pending_payout"
  },
  {
    partnerCode: "CLIPORA-AGENCY",
    memberEmail: "agency-client@example.com",
    signupPlan: "Free / welcome credits",
    purchasedPlan: "Ultra monthly",
    purchaseAmountUsd: 199,
    commissionPercent: 40,
    commissionUsd: 79.6,
    status: "pending_payout"
  },
  {
    partnerCode: "CLIPORA-AGENCY",
    memberEmail: "growth-client@example.com",
    signupPlan: "Growth Intelligence brief",
    purchasedPlan: "Growth Intelligence Agent monthly",
    purchaseAmountUsd: 499,
    commissionPercent: 35,
    commissionUsd: 174.65,
    status: "pending_payout"
  }
];
