export type ServicePage = {
  slug: string;
  title: string;
  turkishTitle: string;
  badge: string;
  keyword: string;
  summary: string;
  primaryCtaLabel: string;
  primaryCtaHref: string;
  secondaryCtaHref?: string;
  bestFor: string;
  inputs: string[];
  outputs: string[];
  delivery: string[];
  sections: { title: string; text: string }[];
  examples: string[];
  status?: "published" | "draft" | "noindex";
  seoPriority?: "high" | "medium" | "low";
  includeInSitemap?: boolean;
  faqItems?: { question: string; answer: string }[];
  internalLinks?: { label: string; href: string }[];
};

const assistantBase = "/dashboard/assistant-workspace";

const coreServicePages: ServicePage[] = [
  {
    slug: "ai-website-builder",
    title: "AI Website Builder",
    turkishTitle: "Yapay Zeka Web Sitesi Oluşturucu",
    badge: "Website builder",
    keyword: "AI Website Builder",
    summary: "Create landing pages, business websites, SaaS pages and full website delivery packages with source files, README setup notes and dashboard handoff.",
    primaryCtaLabel: "Start AI Website Builder",
    primaryCtaHref: `${assistantBase}?mode=project&category=website&idea=AI%20Website%20Builder`,
    secondaryCtaHref: "/pricing",
    bestFor: "Landing pages, company sites, SaaS websites, portfolio sites and launch pages",
    inputs: ["Business idea or product brief", "Target audience", "Sections or page goals", "Brand notes or references"],
    outputs: ["Website plan", "Source ZIP path", "README / setup guide", "Preview and delivery notes"],
    delivery: ["Preview link", "Final ZIP package", "Source files", "README / setup guide", "Revision path"],
    sections: [
      { title: "Build a real website delivery plan", text: "Clipora routes your website request into a structured production plan with page sections, content direction, source package expectations and delivery tracking." },
      { title: "Prepared for source handoff", text: "The workflow is designed around final handoff: preview, downloadable files, README/setup notes and revision status instead of only a text response." }
    ],
    examples: ["SaaS landing page", "Agency website", "Product launch page", "Portfolio website"]
  },
  {
    slug: "ai-app-builder",
    title: "AI App Builder",
    turkishTitle: "Yapay Zeka Uygulama Oluşturucu",
    badge: "App builder",
    keyword: "AI App Builder",
    summary: "Plan web apps, mobile apps, dashboards, admin panels and SaaS MVP packages with modules, screens, source structure and delivery tracking.",
    primaryCtaLabel: "Start AI App Builder",
    primaryCtaHref: `${assistantBase}?mode=project&category=app&idea=AI%20App%20Builder`,
    secondaryCtaHref: "/dashboard/productions",
    bestFor: "SaaS MVPs, mobile app concepts, web apps, dashboards and internal tools",
    inputs: ["App idea", "User roles", "Core features", "Platform target"],
    outputs: ["Feature map", "Screen/module plan", "Source package direction", "README and delivery checklist"],
    delivery: ["Preview plan", "Source package", "README/setup", "Dashboard tracking", "Revision path"],
    sections: [
      { title: "Turn an app idea into production structure", text: "Clipora helps define the app type, modules, screens, quality level and delivery package before full provider/API production." },
      { title: "Useful before final development", text: "The builder is designed to produce a clear implementation package that can become a source ZIP, project brief or admin-tracked delivery." }
    ],
    examples: ["SaaS dashboard", "Mobile booking app", "Admin panel", "Customer portal"]
  },
  {
    slug: "ai-ecommerce-builder",
    title: "AI Ecommerce Builder",
    turkishTitle: "Yapay Zeka E-Ticaret Oluşturucu",
    badge: "Commerce builder",
    keyword: "AI Ecommerce Builder",
    summary: "Create e-commerce pages, product campaigns, product descriptions, product ad kits and store delivery packages for launch-ready commerce workflows.",
    primaryCtaLabel: "Start AI Ecommerce Builder",
    primaryCtaHref: `${assistantBase}?mode=commerce&category=ecommerce&idea=AI%20Ecommerce%20Builder`,
    secondaryCtaHref: "/dashboard/ads",
    bestFor: "Product pages, store landing pages, Shopify/Amazon/Trendyol prep and product ad kits",
    inputs: ["Product link or product idea", "Offer details", "Target platform", "Brand or store notes"],
    outputs: ["Product page plan", "Ad kit", "Descriptions and captions", "Delivery package"],
    delivery: ["Preview", "Final ZIP", "Copy/source files", "Export notes", "Revision path"],
    sections: [
      { title: "Commerce assets in one path", text: "Clipora can prepare product positioning, page structure, ad angles, captions and delivery files around one e-commerce objective." },
      { title: "Built for store and ad handoff", text: "The page connects commerce planning with dashboard delivery, provider tests and future channel integrations." }
    ],
    examples: ["Product landing page", "Shopify offer page", "Amazon product ad kit", "Trendyol campaign package"]
  },
  {
    slug: "ai-video-generator",
    title: "AI Video Generator",
    turkishTitle: "Yapay Zeka Video Üretici",
    badge: "Video generator",
    keyword: "AI Video Generator",
    summary: "Prepare product videos, short clips, multi-format video packs, captions, ratios, thumbnail notes and provider-ready delivery workflows.",
    primaryCtaLabel: "Start AI Video Generator",
    primaryCtaHref: `${assistantBase}?mode=media&category=video&idea=AI%20Video%20Generator`,
    secondaryCtaHref: "/dashboard/videos",
    bestFor: "Short videos, product clips, TikTok/Reels/Shorts assets and multi-format video packs",
    inputs: ["Video idea", "Duration goal", "Style direction", "Platform target"],
    outputs: ["Video plan", "Provider-ready job", "Captions/ratio notes", "Preview and final delivery"],
    delivery: ["Preview link", "MP4/final delivery", "Captions", "Thumbnail notes", "Revision path"],
    sections: [
      { title: "Video production with delivery logic", text: "The workflow keeps focus on final usable assets: preview, final render, export notes and dashboard-tracked revisions." },
      { title: "Low-cost testing path", text: "Users can start with a small provider test before committing to larger or higher-cost generation settings." }
    ],
    examples: ["Product ad video", "Explainer clip", "Shorts package", "Launch teaser"]
  },
  {
    slug: "ai-social-media-ai",
    title: "AI Social Media AI",
    turkishTitle: "Yapay Zeka Sosyal Medya Asistanı",
    badge: "Social media",
    keyword: "AI Social Media AI",
    summary: "Build social posts, captions, campaign angles, content calendars, short-video ideas and platform-ready delivery packages.",
    primaryCtaLabel: "Start AI Social Media AI",
    primaryCtaHref: `${assistantBase}?mode=social&category=social&idea=AI%20Social%20Media%20AI`,
    secondaryCtaHref: "/dashboard/growth",
    bestFor: "Social posts, captions, short-video plans, content calendars and launch campaigns",
    inputs: ["Brand or product", "Platform", "Campaign goal", "Tone of voice"],
    outputs: ["Post ideas", "Captions", "Short-video plan", "Export and publishing notes"],
    delivery: ["Content package", "Caption files", "Platform notes", "Revision path", "Dashboard tracking"],
    sections: [
      { title: "From campaign idea to content package", text: "Clipora turns a rough promotion idea into platform-ready content directions and delivery files." },
      { title: "Connected to growth loops", text: "The social workflow can connect to share-to-earn, referral preparation and organic launch planning." }
    ],
    examples: ["Instagram launch posts", "TikTok short ideas", "LinkedIn campaign", "Caption package"]
  },
  {
    slug: "ai-brand-kit-builder",
    title: "AI Brand Kit Builder",
    turkishTitle: "Yapay Zeka Marka Kiti Oluşturucu",
    badge: "Brand kit",
    keyword: "AI Brand Kit Builder",
    summary: "Prepare brand voice, visual direction, messaging, launch assets and reusable brand delivery notes for creative production.",
    primaryCtaLabel: "Start AI Brand Kit Builder",
    primaryCtaHref: "/dashboard/brand-kit",
    secondaryCtaHref: `${assistantBase}?idea=AI%20Brand%20Kit%20Builder`,
    bestFor: "New brands, product launches, campaign identity, messaging systems and reusable asset kits",
    inputs: ["Brand name", "Audience", "Visual direction", "Product or service"],
    outputs: ["Brand voice", "Visual direction", "Messaging kit", "Reusable asset notes"],
    delivery: ["Brand kit page", "Asset notes", "README-style guide", "Dashboard tracking"],
    sections: [
      { title: "Brand system before production", text: "A clear brand kit helps every later website, app, ad, video and social output stay consistent." },
      { title: "Reusable delivery asset", text: "The workflow is prepared as a reusable package instead of a one-off prompt." }
    ],
    examples: ["Startup brand kit", "Product launch identity", "Campaign style guide", "Founder brand voice"]
  },
  {
    slug: "ai-ads-planner",
    title: "AI Ads Planner",
    turkishTitle: "Yapay Zeka Reklam Planlayıcı",
    badge: "Ads planner",
    keyword: "AI Ads Planner",
    summary: "Plan ad campaigns, creative angles, ROAS notes, ad copy, product ad kits and launch-ready paid media workflows.",
    primaryCtaLabel: "Start AI Ads Planner",
    primaryCtaHref: "/dashboard/ads",
    secondaryCtaHref: `${assistantBase}?mode=commerce&category=campaign&idea=AI%20Ads%20Planner`,
    bestFor: "Meta, TikTok, Google, product campaigns, creative testing and paid media planning",
    inputs: ["Offer", "Audience", "Platform", "Budget or goal"],
    outputs: ["Ad angles", "Creative plan", "Copy variants", "ROAS planning notes"],
    delivery: ["Campaign plan", "Ad copy package", "Creative notes", "Dashboard status"],
    sections: [
      { title: "Ad planning before spend", text: "Use the planner to shape creative angles and campaign structure before connecting live ad APIs." },
      { title: "Works with product and video flows", text: "The ads planner can connect naturally to product ad kits, video generation and commerce delivery packages." }
    ],
    examples: ["Product ad campaign", "TikTok creative plan", "Meta ad angles", "ROAS test plan"]
  },
  {
    slug: "ai-dubbing-voice",
    title: "AI Dubbing & Voice",
    turkishTitle: "Yapay Zeka Dublaj ve Seslendirme",
    badge: "Voice and dubbing",
    keyword: "AI Dubbing & Voice",
    summary: "Prepare voiceover, dubbing, localization, audio delivery notes and future provider-ready voice production workflows.",
    primaryCtaLabel: "Start AI Dubbing & Voice",
    primaryCtaHref: "/dashboard/dubbing",
    secondaryCtaHref: `${assistantBase}?mode=media&category=audio&idea=AI%20Dubbing%20%26%20Voice`,
    bestFor: "Voiceover, dubbing, localization, narration planning and audio package handoff",
    inputs: ["Script", "Language", "Voice direction", "Video or audio goal"],
    outputs: ["Voice plan", "Localization notes", "Audio delivery path", "Provider-ready brief"],
    delivery: ["Audio notes", "Subtitle/localization plan", "Dashboard delivery", "Revision path"],
    sections: [
      { title: "Voice workflow preparation", text: "The page frames dubbing and voice projects as deliverable production packages with script, language and handoff requirements." },
      { title: "Ready for provider connection", text: "Final live audio generation depends on provider/API setup, but the workflow and delivery expectations can be prepared now." }
    ],
    examples: ["Product voiceover", "Multilingual dubbing", "Narration plan", "Localization package"]
  },
  {
    slug: "growth-intelligence-agent",
    title: "AI Growth Intelligence Agent",
    turkishTitle: "Yapay Zeka Rakip İstihbarat Ajanı",
    badge: "Growth intelligence",
    keyword: "AI Growth Intelligence Agent",
    summary: "Monitor public competitor pages, pricing changes, public ad signals, landing pages and review trends, then turn them into weekly executive intelligence reports and Clipora campaign actions.",
    primaryCtaLabel: "Start Growth Intelligence",
    primaryCtaHref: "/growth-intelligence",
    secondaryCtaHref: "/dashboard/growth-intelligence",
    bestFor: "Agencies, ecommerce teams, SaaS companies, local businesses and growth operators tracking competitors",
    inputs: ["Company website", "Competitor URLs", "Public ad library links", "Pricing or product pages", "Target market and report language"],
    outputs: ["Competitor monitoring brief", "Weekly CEO PDF report", "Opportunity alerts", "Recommended campaign actions", "Clipora response production ideas"],
    delivery: ["Dashboard monitoring brief", "PDF report delivery", "Email/Slack alert planning", "Admin review", "Campaign response CTA"],
    sections: [
      { title: "Public competitor monitoring as a service", text: "The Growth Intelligence Agent watches public competitor and market signals instead of generating a single media file. It is designed for recurring monitoring, PDF reports and strategic action planning." },
      { title: "From insights to Clipora production", text: "A price change, new public ad angle or review trend can become an ad video, landing page, social campaign, email sequence or product response brief inside Clipora." }
    ],
    examples: ["Competitor price monitoring", "Public ad signal tracking", "Weekly CEO strategy PDF", "Ecommerce competitor report"],
    internalLinks: [
      { label: "Growth Intelligence plans", href: "/growth-intelligence" },
      { label: "Dashboard monitoring setup", href: "/dashboard/growth-intelligence" },
      { label: "AI Live Sales Agent", href: "/live-sales-credits" },
      { label: "Drone credit packs", href: "/drone-credits" }
    ]
  },
  {
    slug: "ai-bulk-content-builder",
    title: "AI Bulk Content Builder",
    turkishTitle: "Yapay Zeka Toplu İçerik Oluşturucu",
    badge: "Bulk content",
    keyword: "AI Bulk Content Builder",
    summary: "Plan batch content, CSV-driven production, multi-item exports, product content sets and bulk delivery packages.",
    primaryCtaLabel: "Start AI Bulk Content Builder",
    primaryCtaHref: "/dashboard/bulk",
    secondaryCtaHref: `${assistantBase}?idea=AI%20Bulk%20Content%20Builder`,
    bestFor: "Batch product content, social batches, CSV/list-based generation and multi-file delivery packages",
    inputs: ["CSV or item list", "Content type", "Output format", "Delivery goal"],
    outputs: ["Batch plan", "Multi-item content structure", "Export notes", "Delivery tracking"],
    delivery: ["Batch output plan", "ZIP/export package", "CSV notes", "Revision path"],
    sections: [
      { title: "Scale content production", text: "Bulk content workflows help prepare many assets from structured inputs instead of building one item at a time." },
      { title: "Post-launch automation ready", text: "The feature is positioned for growth after core launch while still giving users a visible planning path now." }
    ],
    examples: ["100 product descriptions", "Caption batch", "CSV content plan", "Multi-asset export package"]
  }
];

const nicheTargets = [
  { slug: "small-business", label: "Small Business", tr: "Küçük İşletmeler" },
  { slug: "startups", label: "Startups", tr: "Girişimler" },
  { slug: "agencies", label: "Agencies", tr: "Ajanslar" },
  { slug: "creators", label: "Creators", tr: "İçerik Üreticileri" },
  { slug: "ecommerce", label: "Ecommerce", tr: "E-Ticaret" },
  { slug: "local-business", label: "Local Business", tr: "Yerel İşletmeler" },
  { slug: "dropshipping", label: "Dropshipping", tr: "Dropshipping" }
];

const nicheBaseSlugs = ["ai-website-builder", "ai-ecommerce-builder", "ai-video-generator", "growth-intelligence-agent"];

function nicheSummary(base: ServicePage, target: { label: string }) {
  return `${base.title} for ${target.label} helps teams plan a focused production workflow with SEO content, delivery requirements, source or media handoff, dashboard tracking and admin-managed redirects.`;
}

function buildNichePage(base: ServicePage, target: { slug: string; label: string; tr: string }): ServicePage {
  const keyword = `${base.title} for ${target.label}`;
  return {
    ...base,
    slug: `${base.slug}-for-${target.slug}`,
    title: keyword,
    turkishTitle: `${base.turkishTitle} — ${target.tr} İçin`,
    badge: `${base.badge} niche`,
    keyword,
    summary: nicheSummary(base, target),
    primaryCtaLabel: `Start ${keyword}`,
    primaryCtaHref: `${base.primaryCtaHref}&niche=${encodeURIComponent(target.label)}`,
    bestFor: `${target.label} teams, agencies, operators and businesses that need ${base.title.toLowerCase()} delivery packages`,
    inputs: [...base.inputs, `${target.label} business context`],
    outputs: [...base.outputs, `${target.label} launch assets`],
    delivery: base.delivery,
    sections: [
      { title: `Why ${target.label} teams use ${base.title}`, text: `${keyword} gives ${target.label.toLowerCase()} users a clearer starting point than a generic AI prompt. The page frames the use case, expected inputs, delivery formats and route into the right Clipora production workflow.` },
      { title: `${keyword} delivery workflow`, text: `Clipora can prepare a structured request around ${target.label.toLowerCase()} goals, then route users toward preview, final package, source/media files, README or export notes and revision tracking depending on the selected package.` }
    ],
    examples: [`${target.label} landing page`, `${target.label} campaign package`, `${target.label} content assets`, `${target.label} delivery workflow`]
  };
}

const programmaticNichePages = coreServicePages
  .filter((page) => nicheBaseSlugs.includes(page.slug))
  .flatMap((page) => nicheTargets.map((target) => buildNichePage(page, target)));

export const servicePages: ServicePage[] = [...coreServicePages, ...programmaticNichePages];

export const servicePageMap = new Map(servicePages.map((page) => [page.slug, page]));
