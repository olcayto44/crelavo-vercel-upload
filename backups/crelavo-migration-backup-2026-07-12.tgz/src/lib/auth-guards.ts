import { supabaseBrowser } from "@/lib/supabase";

export function isEmailVerified(user: { email_confirmed_at?: string | null; confirmed_at?: string | null } | null | undefined) {
  return Boolean(user?.email_confirmed_at || user?.confirmed_at);
}

export async function requireVerifiedBrowserUser() {
  const { data, error } = await supabaseBrowser().auth.getUser();
  const user = data.user;

  if (error || !user) {
    return { ok: false as const, message: "You must sign in before continuing.", redirect: "/auth/login" };
  }

  if (!isEmailVerified(user)) {
    return { ok: false as const, message: "You must confirm your email address before using the assistant or starting production. Please open the confirmation link sent to your inbox.", redirect: "/auth/login" };
  }

  return { ok: true as const, user };
}
