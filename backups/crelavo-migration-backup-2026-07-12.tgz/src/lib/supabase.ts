import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL ?? process.env.NEXT_PUBLIC_SUPABASE ?? "";
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY ?? "";

let browserClient: ReturnType<typeof createClient> | null = null;

export const supabaseBrowser = () => {
  if (!browserClient) browserClient = createClient(supabaseUrl, supabaseAnonKey);
  return browserClient;
};

export const supabaseAdmin = () => {
  if (!supabaseServiceKey) throw new Error("Missing SUPABASE_SERVICE_ROLE_KEY");
  return createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });
};
