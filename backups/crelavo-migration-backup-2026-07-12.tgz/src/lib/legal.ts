export const LEGAL_ACCEPTANCE_VERSION = "v1.2-subscription-billing";

export const productionResponsibilityText = "The user confirms, represents, and warrants that they own or have obtained all rights, licenses, permissions, consents, and commercial-use authorizations required for every brand, logo, emblem, trade name, product image, face, likeness, person, voice, music, text, reference material, uploaded file, link, dataset, and any similar content submitted, referenced, requested, or used in a production order. This confirmation applies globally, including the user's country, target markets, publishing platforms, advertising channels, and all applicable local, regional, national, and international laws relating to copyright, trademarks, publicity rights, personality rights, privacy, data protection, advertising, consumer protection, unfair competition, and platform policies.";

export const rightsWarrantyText = "Clipora is a technical automation and AI production tool. Clipora does not verify, guarantee, or certify that user-submitted or user-requested content is lawful, policy-compliant, non-infringing, or suitable for publication in any country or platform. The user is solely and exclusively responsible for every production request, uploaded or linked material, selected brand/logo/face/voice/music/product reference, generated output, advertisement, publication, campaign, and downstream use. The user agrees to defend, indemnify, and hold harmless Clipora, its owners, directors, employees, contractors, and service providers from and against any claim, notice, takedown, lawsuit, loss, damage, penalty, license fee, settlement, advertising-account sanction, platform restriction, legal cost, or regulatory action arising from the user's content, instructions, materials, publications, or use of the generated outputs.";

export const billingTermsText = "Monthly and yearly subscription packages renew automatically through the payment provider until cancelled. By starting a subscription, the user authorizes recurring charges to the saved payment method for the selected billing interval and acknowledges that monthly plans renew monthly and yearly plans renew yearly. Payment card data is stored and processed by the payment provider, not directly by Clipora. If a recurring payment fails, Clipora may notify the user, retry payment according to provider settings, restrict new production starts, suspend subscription benefits, or require payment method updates before service continues. One-time top-up credit packages are not subscriptions, do not renew automatically, and may be purchased repeatedly whenever the user chooses. Credits, subscription benefits, reserved production credits, failed-payment handling, cancellation timing, invoices, receipts, and refund eligibility are governed by the package terms shown at checkout, dashboard notices, and applicable payment provider records.";

export function legalAcceptanceSnapshot(input: { productionType: string; packageId: string; title: string; userEmail?: string }) {
  return {
    version: LEGAL_ACCEPTANCE_VERSION,
    accepted: true,
    acceptedAt: new Date().toISOString(),
    productionType: input.productionType,
    packageId: input.packageId,
    title: input.title,
    userEmail: input.userEmail ?? "",
    responsibilityText: productionResponsibilityText,
    rightsWarrantyText,
    billingTermsText
  };
}
