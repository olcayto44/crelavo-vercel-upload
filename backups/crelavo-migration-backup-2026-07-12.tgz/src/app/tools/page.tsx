import Link from "next/link";
import { Header } from "@/components/Header";
import { footerGroups } from "@/lib/site-content";
import { getConfiguredSiteContentConfig } from "@/lib/site-content-loader";

const toolGroups = footerGroups.filter((group) => ["Products", "Video Tools", "Music and Audio Tools", "Business and File Production", "More Production Categories"].includes(group.title));

export default async function ToolsPage() {
  const siteContent = await getConfiguredSiteContentConfig();

  return (
    <>
      <Header navLinks={siteContent.navLinks} />
      <main className="container section tools-page tools-catalog-page">
        <section className="production-hero-card admin-overview-hero">
          <span className="badge">Tools catalog</span>
          <h1>Choose a Clipora tool</h1>
          <p>
            Browse Clipora tools by production area. Each tool opens a focused information page first, then the user can continue into the production workspace, category page, dashboard or credit page.
          </p>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 16 }}>
            <Link className="btn" href="/dashboard/assistant-workspace">Start a request</Link>
            <Link className="btn secondary" href="/categories">Open categories</Link>
            <Link className="btn secondary" href="/pricing">View credits</Link>
          </div>
        </section>

        <section className="admin-category-grid" style={{ marginTop: 18 }}>
          {toolGroups.map((group, index) => (
            <div className={`card admin-category-card tools-catalog-card tools-tone-${index % 5}`} key={group.title}>
              <span className="badge">{group.title}</span>
              <h2>{group.title}</h2>
              <p>Open a tool guide, understand what it does, then continue to the right production flow.</p>
              <div className="plan-feature-groups">
                {group.links.map((link, linkIndex) => (
                  <Link className={`admin-inline-select tools-link-tone-${linkIndex % 4}`} href={link.href} key={`${group.title}-${link.label}`}>
                    <b>{link.label}</b>
                    <small>Open guide and start path</small>
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </section>
      </main>
    </>
  );
}
