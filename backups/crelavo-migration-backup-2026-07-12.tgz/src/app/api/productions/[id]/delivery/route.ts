import { buildDeliveryEntries, buildDeliveryManifest, buildDeliveryReadme, buildDeliveryZip, buildPreviewHtml, buildSourceGuide } from "@/lib/automatic-delivery-builder";
import { supabaseAdmin } from "@/lib/supabase";

function responseWithText(content: string, filename: string, contentType = "text/markdown; charset=utf-8") {
  return new Response(content, {
    headers: {
      "Content-Type": contentType,
      "Content-Disposition": `attachment; filename="${filename}"`
    }
  });
}

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { searchParams } = new URL(request.url);
  const file = searchParams.get("file") ?? "manifest";

  const { data, error } = await supabaseAdmin()
    .from("production_requests")
    .select("id, title, prompt, production_type, package_id, request_metadata, input_json, materials_json")
    .eq("id", id)
    .maybeSingle();

  if (error || !data) {
    return Response.json({ error: error?.message ?? "Production not found" }, { status: 404 });
  }

  const safeTitle = String(data.title ?? "clipora-delivery").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "clipora-delivery";

  if (file === "readme") return responseWithText(buildDeliveryReadme(data), `${safeTitle}-readme.md`);
  if (file === "source") return responseWithText(buildSourceGuide(data), `${safeTitle}-source-guide.md`);
  if (file === "preview") return responseWithText(buildPreviewHtml(data), `${safeTitle}-preview.html`, "text/html; charset=utf-8");
  if (file === "zip") {
    const zip = buildDeliveryZip(buildDeliveryEntries(data));
    return new Response(zip, {
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename="${safeTitle}-delivery-package.zip"`
      }
    });
  }

  return Response.json(buildDeliveryManifest(data));
}
