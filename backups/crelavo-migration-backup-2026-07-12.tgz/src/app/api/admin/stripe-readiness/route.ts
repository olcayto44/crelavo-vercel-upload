import { adminRequiredResponse, isAdminRequest } from "@/lib/admin-guard";
import { normalizePackageConfig, PACKAGE_CONFIG_KEY } from "@/lib/package-config";
import { supabaseAdmin } from "@/lib/supabase";

function hasEnv(name: string) {
  const value = process.env[name];
  return Boolean(value && !value.includes("TODO") && !value.includes("your_") && !value.includes("change_me"));
}

function compact(values: Array<string | undefined>) {
  return values.map((value) => String(value ?? "").trim()).filter(Boolean);
}

export async function GET(request: Request) {
  if (!isAdminRequest(request)) return adminRequiredResponse();

  try {
    const { data } = await supabaseAdmin()
      .from("platform_configs")
      .select("value")
      .eq("key", PACKAGE_CONFIG_KEY)
      .maybeSingle();
    const config = normalizePackageConfig(data?.value);
    const stripeCore = ["STRIPE_SECRET_KEY", "NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY", "STRIPE_WEBHOOK_SECRET"];
    const packageEnvNames = Array.from(new Set(config.creditPackages.flatMap((item) => {
      if (item.planType === "topup" || item.planType === "production_one_time") return compact([item.stripePriceEnv]);
      if (item.planType === "service_subscription") return compact([item.monthlyStripePriceEnv]);
      return compact([item.monthlyStripePriceEnv, item.yearlyStripePriceEnv]);
    })));
    const paymentLinkEntries = config.creditPackages.flatMap((item) => {
      if (item.planType === "topup" || item.planType === "production_one_time") return [{ packageId: item.id, label: item.name, billing: "one_time", url: item.paymentLinkUrl ?? "" }];
      if (item.planType === "service_subscription") return [{ packageId: item.id, label: item.name, billing: "monthly", url: item.monthlyPaymentLinkUrl ?? "" }];
      return [
        { packageId: item.id, label: item.name, billing: "monthly", url: item.monthlyPaymentLinkUrl ?? "" },
        { packageId: item.id, label: item.name, billing: "yearly", url: item.yearlyPaymentLinkUrl ?? "" }
      ];
    });
    const paymentLinksConfigured = paymentLinkEntries.filter((entry) => entry.url.trim()).length;
    const required = [...stripeCore, ...packageEnvNames];
    const missing = required.filter((name) => !hasEnv(name));
    const ready = missing.length === 0;
    const paymentLinkFallbackReady = paymentLinksConfigured > 0;

    return Response.json({
      ready,
      paymentLinkFallbackReady,
      required,
      missing,
      core: stripeCore.map((name) => ({ name, configured: hasEnv(name) })),
      priceIds: packageEnvNames.map((name) => ({ name, configured: hasEnv(name) })),
      paymentLinks: paymentLinkEntries.map((entry) => ({ ...entry, configured: Boolean(entry.url.trim()) })),
      paymentLinksConfigured,
      packageCount: config.creditPackages.length,
      note: ready
        ? "Stripe API checkout has all required core keys and configured package price env vars."
        : paymentLinkFallbackReady
          ? "Stripe API env is incomplete, but Payment Links are configured for early-launch manual activation. Secret values are never exposed."
          : "Missing env names only are shown. Add Payment Links for early launch or add Stripe API env for automated checkout. Secret values are never exposed."
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Stripe readiness could not be checked.";
    return Response.json({ error: message }, { status: 500 });
  }
}
