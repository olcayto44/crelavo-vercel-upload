import Link from "next/link";
import { DashboardShell } from "@/components/DashboardShell";
import { RequestsTable } from "@/components/RequestsTable";
import { SignOutButton } from "@/components/SignOutButton";
import { CreditBalanceCard } from "@/components/CreditBalanceCard";

const workflowStarters = [
  {
    badge: "Website builder",
    title: "AI Website Builder",
    text: "Plan a landing page, business site, SaaS page or full website package with source files, README, setup guide and ZIP handoff.",
    href: "/ai-website-builder",
    cta: "Open website builder"
  },
  {
    badge: "App builder",
    title: "AI App Builder",
    text: "Start a mobile app, web app, admin panel or SaaS MVP plan with modules, screens, source package and delivery tracking.",
    href: "/ai-app-builder",
    cta: "Open app builder"
  },
  {
    badge: "Commerce builder",
    title: "AI Ecommerce Builder",
    text: "Create store pages, product ad kits, product descriptions, offer assets, checkout notes and e-commerce delivery files.",
    href: "/ai-ecommerce-builder",
    cta: "Open ecommerce builder"
  },
  {
    badge: "Video generator",
    title: "AI Video Generator",
    text: "Prepare short videos, product clips, multi-format exports, captions, ratios, thumbnail notes and provider-ready video jobs.",
    href: "/ai-video-generator",
    cta: "Open video generator"
  },
  {
    badge: "Live sales",
    title: "Live Sales Control Center",
    text: "Start or stop avatar live sales sessions, select extra setup features, and track remaining fair-use live hours.",
    href: "/dashboard/live-sales-agent",
    cta: "Open live control"
  },
  {
    badge: "Drone shoot",
    title: "Drone Shoot Panel",
    text: "Prepare the purchased drone package with location, route, map area, camera movement and start the drone production request.",
    href: "/dashboard/drone-shoot",
    cta: "Open drone shoot"
  },
  {
    badge: "Social media",
    title: "AI Social Media AI",
    text: "Build social posts, captions, short-video plans, campaign angles, platform export notes and share-ready delivery packages.",
    href: "/ai-social-media-ai",
    cta: "Open social media AI"
  },
  {
    badge: "Brand kit",
    title: "AI Brand Kit Builder",
    text: "Prepare brand voice, visual direction, content kit, reusable assets and dashboard delivery notes for a launch package.",
    href: "/ai-brand-kit-builder",
    cta: "Open brand kit"
  },
  {
    badge: "Bulk tools",
    title: "AI Bulk Content Builder",
    text: "Plan batch content, CSV-driven production, multi-item exports and post-launch bulk automation preparation.",
    href: "/ai-bulk-content-builder",
    cta: "Open bulk builder"
  },
  {
    badge: "Voice / dubbing",
    title: "AI Dubbing & Voice",
    text: "Prepare voiceover, dubbing, localization notes and audio-ready delivery workflows for future provider/API connection.",
    href: "/ai-dubbing-voice",
    cta: "Open dubbing"
  },
  {
    badge: "Ads planning",
    title: "AI Ads Planner",
    text: "Prepare paid ad campaign structure, ROAS notes, creative angles and post-launch ad workflow planning.",
    href: "/ai-ads-planner",
    cta: "Open ads planner"
  },
  {
    badge: "Connections",
    title: "AI Channel Connections",
    text: "Prepare future Meta, TikTok, Shopify, Amazon, Trendyol and store connection targets before final API setup.",
    href: "/dashboard/connections",
    cta: "Open connections"
  },
  {
    badge: "Growth",
    title: "AI Growth Rewards",
    text: "Review share-to-earn, referral prep, watermark rules and organic growth loops for launch readiness.",
    href: "/dashboard/growth",
    cta: "Open growth"
  },
  {
    badge: "Partners",
    title: "Partner Program",
    text: "Prepare referral links, creator assets, future commission tracking and partner rewards before payout API setup.",
    href: "/dashboard/partners",
    cta: "Open partners"
  },
  {
    badge: "Delivery center",
    title: "Production Delivery Center",
    text: "Open all production requests, delivery statuses, preview links, source packages, README files and revision paths.",
    href: "/dashboard/productions",
    cta: "Open deliveries"
  },
  {
    badge: "Credits",
    title: "Credits & Billing",
    text: "Check credit balance, top-up flow, billing status and payment readiness before live production spend.",
    href: "/dashboard/credits",
    cta: "Open credits"
  },
  {
    badge: "Provider test",
    title: "Low-Cost Test",
    text: "Run a small 5-second / 720p provider test before committing to full production or higher-cost settings.",
    href: "/dashboard/assistant-workspace?providerTest=1",
    cta: "Run low-cost test"
  }
];

export default function DashboardPage() {
  return (
    <DashboardShell>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 16, alignItems: "center", marginBottom: 20 }}>
        <div>
          <h1 style={{ margin: 0 }}>Dashboard</h1>
          <p style={{ color: "var(--muted)", margin: "8px 0 0" }}>Production planning, live stage tracking, dashboard delivery and post-launch social/e-commerce export preparation.</p>
        </div>
        <SignOutButton />
      </div>
      <div className="kpi">
        <CreditBalanceCard />
        <div className="card"><span>Active</span><strong>2</strong><p>Requests in production</p></div>
        <div className="card"><span>Ready</span><strong>1</strong><p>Delivered videos</p></div>
        <div className="card"><span>Spent</span><strong>340</strong><p>Credits used this month</p></div>
      </div>
      <section className="dashboard-workflow-starters" style={{ marginTop: 20 }}>
        <div className="sample-video-head">
          <div>
            <span className="badge">AI builder launchpad</span>
            <h2>Choose the AI builder you want to open</h2>
            <p className="section-lead">Website, app, ecommerce, video, social media, brand kit, bulk content, dubbing and low-cost test flows all open their own ready-start path.</p>
          </div>
          <Link className="btn secondary" href="/dashboard/productions">View productions</Link>
        </div>
        <div className="dashboard-workflow-grid">
          {workflowStarters.map((item) => (
            <Link className="card clickable-credit-card dashboard-workflow-card" href={item.href} key={item.title}>
              <span className="badge">{item.badge}</span>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
              <span className="btn">{item.cta}</span>
            </Link>
          ))}
        </div>
      </section>
      <div className="card" style={{ marginTop: 20 }}>
        <h2>Recent video requests</h2>
        <RequestsTable />
        <div style={{ marginTop: 18 }}><Link className="btn" href="/dashboard/assistant-workspace">Start live production</Link></div>
      </div>
    </DashboardShell>
  );
}
