import Link from "next/link";
import { DashboardShell } from "@/components/DashboardShell";
import { rewardCreditRules, watermarkPolicy } from "@/lib/growth";

export default function DashboardGrowthPage() {
  return (
    <DashboardShell>
      <section className="card">
        <span className="badge">Post-launch growth backlog</span>
        <h2>Earn and share with Clipora</h2>
        <p style={{ color: "var(--muted)" }}>These growth features stay in planning mode until the core launch is validated. Reward credits, referral tracking and share loops will be built after API/env setup and payment E2E are complete.</p>
      </section>

      <section className="grid" style={{ marginTop: 20 }}>
        <div className="card">
          <span className="badge">Preview watermark</span>
          <h3>Free preview outputs stay shareable</h3>
          <p>Free previews can include a Clipora preview watermark. Paid final delivery can become watermark-free once credits/payment eligibility is confirmed.</p>
          <ul>{watermarkPolicy.map((rule) => <li key={rule}>{rule}</li>)}</ul>
        </div>
        <div className="card">
          <span className="badge">Referral MVP</span>
          <h3>Referral and affiliate tracking</h3>
          <p>Referral links can track signups and first production starts before Stripe conversion/payout rules are connected.</p>
          <p className="workspace-action-note warning">Commission, payout and paid conversion attribution stay blocked until Stripe is available.</p>
          <Link className="btn secondary" href="/dashboard/partners">Open partner program</Link>
        </div>
      </section>

      <section className="card" style={{ marginTop: 20 }}>
        <span className="badge">Share-to-earn draft rules</span>
        <h2>Reward credit examples</h2>
        <div className="admin-info-grid">
          {rewardCreditRules.map((rule) => (
            <div key={rule.action}>
              <span>{rule.action}</span>
              <strong>{rule.credits.toLocaleString()} credits</strong>
              <small>{rule.limit}</small>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 18 }}>
          <Link className="btn" href="/dashboard/assistant-workspace">Start a production to share</Link>
          <Link className="btn secondary" href="/dashboard/credits" style={{ marginLeft: 10 }}>View credits</Link>
        </div>
      </section>
    </DashboardShell>
  );
}
