import type { MetadataRoute } from "next";
import { footerInfoPages } from "@/lib/footer-info-pages";
import { freeTools } from "@/lib/free-tools";
import { getConfiguredServicePages } from "@/lib/service-pages-loader";

const privateRoutePrefixes = ["/admin", "/api", "/auth", "/dashboard", "/wp-admin"];

const publicRoutes = [
  { path: "", priority: 1, changeFrequency: "weekly" as const },
  { path: "/categories", priority: 0.9, changeFrequency: "weekly" as const },
  { path: "/tools", priority: 0.88, changeFrequency: "weekly" as const },
  { path: "/free-tools", priority: 0.86, changeFrequency: "weekly" as const },
  { path: "/affiliate", priority: 0.78, changeFrequency: "monthly" as const },
  { path: "/pricing", priority: 0.85, changeFrequency: "monthly" as const },
  { path: "/blog", priority: 0.82, changeFrequency: "monthly" as const },
  { path: "/contact", priority: 0.72, changeFrequency: "monthly" as const },
  { path: "/styles", priority: 0.7, changeFrequency: "monthly" as const }
];

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL ?? "https://cliporastudio.ai";
  const now = new Date();

  if (publicRoutes.some((route) => privateRoutePrefixes.some((prefix) => route.path.startsWith(prefix)))) {
    throw new Error("Sitemap can only include public marketing routes.");
  }

  const infoRoutes = footerInfoPages.map((page) => ({
    path: `/products/${page.slug}`,
    priority: 0.74,
    changeFrequency: "monthly" as const
  }));

  const configuredServicePages = await getConfiguredServicePages();
  const serviceRoutes = configuredServicePages
    .filter((page) => (page.status ?? "published") === "published" && page.includeInSitemap !== false)
    .map((page) => ({
      path: `/${page.slug}`,
      priority: page.seoPriority === "high" ? 0.88 : page.seoPriority === "low" ? 0.64 : 0.76,
      changeFrequency: page.seoPriority === "high" ? "weekly" as const : "monthly" as const
    }));

  const freeToolRoutes = freeTools.map((tool) => ({
    path: `/free-tools/${tool.slug}`,
    priority: 0.7,
    changeFrequency: "monthly" as const
  }));

  return [...publicRoutes, ...serviceRoutes, ...freeToolRoutes, ...infoRoutes]
    .filter((route) => !privateRoutePrefixes.some((prefix) => route.path.startsWith(prefix)))
    .map((route) => ({
      url: `${baseUrl}${route.path}`,
      lastModified: now,
      changeFrequency: route.changeFrequency,
      priority: route.priority
    }));
}
