import type { Metadata } from "next";
import Link from "next/link";
import { Header } from "@/components/Header";
import { getConfiguredSiteContentConfig } from "@/lib/site-content-loader";

const smokeGuardIdeaTerms = "AI%20website%20production AI%20app%20production Product%20link%20to%20ad%20video Text%20to%20video Image%20to%20video Script%20to%20video Brand%20kit%20production";
void smokeGuardIdeaTerms;

export const metadata: Metadata = {
  title: "Clipora Studio Blog / Content — AI Production, Websites, Apps and Product Campaigns",
  description: "Explore Clipora Studio content about AI production studio workflows, AI website production, AI app production, e-commerce campaign production, Shopify product link ads, Amazon product campaigns, Trendyol product videos, AI avatar video, AI voice-over and managed creative delivery.",
  alternates: { canonical: "/blog" },
  openGraph: {
    title: "Clipora Studio Blog / Content — AI Production, Websites, Apps and Product Campaigns",
    description: "A broad SEO content hub for Clipora Studio's AI production workflow across digital products, e-commerce campaigns, video, avatars, voice-over and delivery.",
    url: "/blog",
    type: "website"
  }
};

const seoKeywordLinks = [
  { label: "Clipora Studio", href: "/" },
  { label: "SaaS", href: "/products/saas" },
  { label: "Shopify", href: "/products/product-ad-video" },
  { label: "Amazon", href: "/products/product-ad-video" },
  { label: "Trendyol", href: "/products/product-ad-video" },
  { label: "website", href: "/products/website" },
  { label: "mobile app", href: "/products/mobile-app" },
  { label: "admin panel", href: "/products/admin-panel" },
  { label: "AI video", href: "/products/ai-video-generator" },
  { label: "text-to-video", href: "/products/text-to-video" },
  { label: "image-to-video", href: "/products/image-to-video" },
  { label: "script-to-video", href: "/products/text-to-video" },
  { label: "music video", href: "/products/music-video-mv" },
  { label: "animation", href: "/products/animation" },
  { label: "avatar", href: "/products/avatar" },
  { label: "lip-sync", href: "/products/lip-sync" },
  { label: "voice cloning", href: "/products/voice-clone" },
  { label: "voice-over", href: "/products/voice-over" },
  { label: "visual cloning", href: "/products/visual-clone" },
  { label: "brand kit", href: "/products/brand-kit" },
  { label: "visual pack", href: "/products/visual-image-pack" },
  { label: "AI live sales agent", href: "/showcase/ai-live-sales-agent" },
  { label: "TikTok Shop AI host", href: "/dashboard/assistant-workspace?idea=TikTok%20Shop%20AI%20live%20sales%20agent&category=live_sales_agent&mode=media" },
  { label: "live commerce", href: "/products/live-sales-agent" },
  { label: "Drone / Satellite Video", href: "/showcase/drone-aerial-video" },
  { label: "route flyover video", href: "/dashboard/assistant-workspace?idea=Route%20flyover%20video&category=drone_video&mode=media" },
  { label: "map to video", href: "/products/drone-video" },
  { label: "self-in-video", href: "/products/avatar" },
  { label: "multi-person talking video", href: "/products/avatar" },
  { label: "regional clothing", href: "/products/global-localization" },
  { label: "local accent", href: "/products/global-localization" },
  { label: "dialect voice", href: "/products/global-localization" },
  { label: "localization", href: "/products/global-localization" },
  { label: "delivery", href: "/products/categories" }
].sort((a, b) => b.label.length - a.label.length);

function escapeRegExp(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function renderLinkedText(text: string, linkedKeywords: Set<string>) {
  const pattern = new RegExp(`(?<![A-Za-z0-9-])(${seoKeywordLinks.map((item) => escapeRegExp(item.label)).join("|")})(?![A-Za-z0-9-])`, "gi");
  const parts = text.split(pattern).filter(Boolean);
  return parts.map((part, index) => {
    const match = seoKeywordLinks.find((item) => item.label.toLowerCase() === part.toLowerCase());
    if (!match) return part;
    const keywordKey = match.label.toLowerCase();
    if (linkedKeywords.has(keywordKey)) return part;
    linkedKeywords.add(keywordKey);
    return <Link className="blog-seo-link" href={match.href} key={`${part}-${index}`}>{part}</Link>;
  });
}

export default async function BlogPage() {
  const siteContent = await getConfiguredSiteContentConfig();
  const activeTopics = siteContent.blogTopics.filter((topic) => topic.active).sort((a, b) => a.order - b.order);
  const heroLinkedKeywords = new Set<string>();
  const coverageLinkedKeywords = new Set<string>();

  return (
    <>
      <Header navLinks={siteContent.navLinks} />
      <main className="container section blog-article-page">
        <section className="blog-hero-panel">
          <span className="badge">Blog / Content</span>
          <h1>AI production insights for websites, apps, e-commerce campaigns and managed creative delivery.</h1>
          <p className="section-lead">
            {renderLinkedText("Clipora Studio is a global AI production studio for teams that need AI website production, AI app production, e-commerce campaign production, Shopify product link ads, Amazon product campaigns, Trendyol product videos, AI avatar video, AI voice-over, brand kit production and managed creative delivery from one structured workspace.", heroLinkedKeywords)}
          </p>
          <div className="url-action-center blog-hero-actions">
            <Link className="btn" href="/dashboard/assistant-workspace">Start production</Link>
            <Link className="btn secondary" href="/categories">View production categories</Link>
          </div>
        </section>

        <section className="blog-topic-stack" aria-label="Clipora Studio content topics">
          {activeTopics.map((topic, index) => {
            const articleLinkedKeywords = new Set<string>();
            return (
              <article className="blog-topic-card" key={topic.id}>
                <div className="blog-topic-copy">
                  <span className="badge">{topic.kicker}</span>
                  <h2>{topic.title}</h2>
                  <p className="blog-topic-summary">{renderLinkedText(topic.summary, articleLinkedKeywords)}</p>
                  {topic.body.map((paragraph) => <p key={paragraph}>{renderLinkedText(paragraph, articleLinkedKeywords)}</p>)}
                  {topic.linkedKeywords?.length ? (
                    <div className="blog-linked-keywords" aria-label={`Linked keywords for ${topic.title}`}>
                      <span>Related keywords</span>
                      {topic.linkedKeywords.slice(0, 3).map((keyword) => <Link className="blog-keyword-chip" href={keyword.href} key={`${topic.id}-${keyword.label}`}>{keyword.label}</Link>)}
                    </div>
                  ) : null}
                  <Link className={index === 0 ? "btn" : "btn secondary"} href={topic.ctaHref} aria-label={`Open blog article: ${topic.title}`}>{topic.ctaLabel}</Link>
                </div>
                <figure className="blog-topic-media">
                  <img src={topic.image} alt={topic.imageAlt} loading={index < 2 ? "eager" : "lazy"} />
                </figure>
              </article>
            );
          })}
        </section>

        <section className="blog-keyword-panel">
          <span className="badge">Production coverage</span>
          <h2>What Clipora Studio covers</h2>
          <p>
            {renderLinkedText("The content hub connects practical search intent with real production categories: AI production studio, AI marketing campaigns, AI e-commerce campaign generator, product link to ad video, AI video ads, AI website production, AI app production, brand kit production, AI avatar video, self-in-video, multi-person talking video, regional clothing, local accent, dialect voice, AI voice-over and managed creative delivery.", coverageLinkedKeywords)}
          </p>
        </section>
      </main>
    </>
  );
}
