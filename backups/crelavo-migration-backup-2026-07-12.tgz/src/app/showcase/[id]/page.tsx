import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, CheckCircle2, PlayCircle, Sparkles } from "lucide-react";
import { Header } from "@/components/Header";
import { SiteStructuredData } from "@/components/SiteStructuredData";
import { getConfiguredSiteContentConfig } from "@/lib/site-content-loader";
import { getShowcaseItem, showcaseItems } from "@/lib/showcase-items";

export function generateStaticParams() {
  return showcaseItems.map((item) => ({ id: item.id }));
}

type ShowcasePageProps = {
  params: Promise<{ id: string }>;
};

export async function generateMetadata({ params }: ShowcasePageProps) {
  const { id } = await params;
  const item = getShowcaseItem(id);
  if (!item) return { title: "Showcase detail | Clipora Studio" };
  return {
    title: `${item.title} | Clipora Studio`,
    description: item.longDescription
  };
}

export default async function ShowcaseDetailPage({ params }: ShowcasePageProps) {
  const [{ id }, siteContent] = await Promise.all([params, getConfiguredSiteContentConfig()]);
  const item = getShowcaseItem(id);
  if (!item) notFound();
  const relatedItems = showcaseItems.filter((entry) => entry.group === item.group && entry.id !== item.id).slice(0, 3);

  return (
    <>
      <SiteStructuredData />
      <Header navLinks={siteContent.navLinks} />
      <main className="showcase-detail-page">
        <section className={`container showcase-detail-hero tone-${item.tone}`}>
          <div className="showcase-detail-copy">
            <Link className="showcase-back-link" href="/">
              <ArrowLeft size={16} /> Back to homepage
            </Link>
            <span className="badge"><Sparkles size={15} /> {item.eyebrow}</span>
            <h1>{item.title}</h1>
            <p>{item.longDescription}</p>
            <div className="showcase-detail-actions">
              <Link className="btn" href={item.primaryCtaHref}>{item.primaryCtaLabel}</Link>
              <Link className="btn secondary" href={item.secondaryCtaHref}>{item.secondaryCtaLabel}</Link>
            </div>
          </div>
          <div className="showcase-video-panel" aria-label={`${item.title} information video area`}>
            {item.videoUrl ? (
              <video className="showcase-detail-video" src={item.videoUrl} controls playsInline preload="metadata" poster={item.imageUrl} />
            ) : (
              <>
                <div className="showcase-video-art" style={item.imageUrl ? { backgroundImage: `linear-gradient(180deg, rgba(2,6,23,.10), rgba(2,6,23,.78)), url(${item.imageUrl})` } : undefined} />
                <div className="showcase-video-overlay">
                  <span><PlayCircle size={46} /></span>
                  <strong>{item.videoTitle}</strong>
                  <p>{item.videoDescription}</p>
                  <small>Video placeholder — demo/explainer video can be connected here.</small>
                </div>
              </>
            )}
          </div>
        </section>

        <section className="container showcase-detail-grid-section">
          <div className="showcase-info-card">
            <span className="badge">Highlights</span>
            <h2>What this page explains</h2>
            <ul>
              {item.highlights.map((highlight) => (
                <li key={highlight}><CheckCircle2 size={18} /> {highlight}</li>
              ))}
            </ul>
          </div>

          <div className="showcase-info-card">
            <span className="badge">Workflow</span>
            <h2>How it works</h2>
            <ol>
              {item.workflow.map((step) => (
                <li key={step}>{step}</li>
              ))}
            </ol>
          </div>

          <div className="showcase-info-card showcase-wide-card">
            <span className="badge">Best for</span>
            <h2>Recommended use cases</h2>
            <div className="showcase-pill-row">
              {item.bestFor.map((useCase) => (
                <span key={useCase}>{useCase}</span>
              ))}
            </div>
          </div>
        </section>

        {relatedItems.length ? (
          <section className="container showcase-related-section">
            <div className="sample-video-head">
              <div>
                <span className="badge">Related</span>
                <h2>More {item.group === "feature" ? "production features" : "production categories"}</h2>
                <p className="section-lead">Explore other cards from the same moving showcase.</p>
              </div>
            </div>
            <div className="showcase-related-grid">
              {relatedItems.map((related) => (
                <Link className={`showcase-related-card tone-${related.tone}`} href={related.href} key={related.id}>
                  <span>{related.kicker}</span>
                  <strong>{related.title}</strong>
                  <p>{related.description}</p>
                </Link>
              ))}
            </div>
          </section>
        ) : null}
      </main>
    </>
  );
}
