import type { Metadata } from "next";
import { Suspense } from "react";
import { AdminFooterVisibility } from "@/components/AdminFooterVisibility";
import { LiveVisitorTracker } from "@/components/LiveVisitorTracker";
import { PartnerReferralTracker } from "@/components/PartnerReferralTracker";
import { SiteFooter } from "@/components/SiteFooter";
import "./globals.css";

const siteUrl = process.env.NEXT_PUBLIC_APP_URL ?? "https://crelavo.com";
const siteName = "Crelavo";
const title = "Crelavo — AI Production Studio for Websites, Apps, E-commerce and Product Campaigns";
const description = "Crelavo is a global AI production studio for websites, mobile apps, e-commerce product campaigns, Shopify, Amazon and Trendyol product links, ad videos, avatars, visuals, voice-over and managed creative delivery.";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  applicationName: siteName,
  title: {
    default: title,
    template: `%s | ${siteName}`
  },
  description,
  keywords: [
    "AI production studio",
    "AI creative production studio",
    "AI website builder service",
    "AI app production",
    "AI e-commerce campaign generator",
    "Shopify product link ad video",
    "Amazon product ad video",
    "Trendyol product campaign",
    "product link to ad video",
    "AI video ads",
    "AI marketing campaign platform",
    "AI avatar video",
    "AI voice-over",
    "AI image generation",
    "brand kit production",
    "managed AI production"
  ],
  creator: siteName,
  publisher: siteName,
  category: "AI production studio",
  alternates: {
    canonical: "/"
  },
  openGraph: {
    title,
    description,
    url: siteUrl,
    siteName,
    type: "website",
    locale: "en_US"
  },
  twitter: {
    card: "summary_large_image",
    title,
    description
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1
    }
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Suspense fallback={null}><AdminFooterVisibility /></Suspense>
        <Suspense fallback={null}><LiveVisitorTracker /></Suspense>
        <Suspense fallback={null}><PartnerReferralTracker /></Suspense>
        {children}
        <SiteFooter />
      </body>
    </html>
  );
}
