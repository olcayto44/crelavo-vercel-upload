import Link from "next/link";
import { BadgeCheck, PackageCheck, Send } from "lucide-react";
import { CampaignPromoSlot } from "@/components/CampaignPromoSlot";
import { CategoryGroupBrowser } from "@/components/CategoryGroupBrowser";
import { Header } from "@/components/Header";
import { HomeShowcaseSlider, type HomeShowcaseSlide } from "@/components/HomeShowcaseSlider";
import { categoryShowcaseItems } from "@/lib/showcase-items";
import { getConfiguredSiteContentConfig } from "@/lib/site-content-loader";

type CategoryShowcaseSlide = HomeShowcaseSlide & { section?: "launcher" | "features" | "categories"; order?: number; active?: boolean };

function categorySlides(slides: CategoryShowcaseSlide[]) {
  const configured = slides
    .filter((slide) => slide.section === "categories" && slide.active)
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  return configured.length ? configured : categoryShowcaseItems;
}

const deliverySteps = [
  {
    icon: PackageCheck,
    title: "1. Choose a category",
    text: "Choose campaign, AI agent, localization, video, website, mobile app, brand kit, document, visual or admin panel production."
  },
  {
    icon: Send,
    title: "2. Submit the request",
    text: "Write the platform, style, features, pages, screens, files and delivery expectations."
  },
  {
    icon: BadgeCheck,
    title: "3. Receive the files",
    text: "Admin adds previews, ZIP packages, source files, README and delivery notes to the user dashboard."
  }
];

export default async function CategoriesPage() {
  const siteContent = await getConfiguredSiteContentConfig();

  return (
    <>
      <Header navLinks={siteContent.navLinks} />
      <main className="container section">
        <section className="promo-top-layout">
          <div>
            <span className="badge">Production categories</span>
            <h1>Choose what you want Clipora to produce</h1>
            <p className="section-lead">
              Clipora is now a broader AI production platform: Text-to-Campaign, AI Agents, Global Localization, video, websites, mobile apps, visuals, brand kits, document packs, and admin-panel projects can all start from one managed request.
            </p>
          </div>
          <div className="promo-corner-slot categories-promo-slot"><CampaignPromoSlot /></div>
        </section>

        <section className="production-hero-card clean-feed-section category-delivery-template">
          <span className="badge">Category-based delivery template</span>
          <h2>Choose the production type first, then track delivery files from the panel</h2>
          <p>
            Every category follows the same core flow: the user creates a request, credits are reserved, admin manages production and delivery links are added to the dashboard.
          </p>
          <div className="delivery-step-grid">
            {deliverySteps.map((step) => {
              const Icon = step.icon;
              return (
                <div className="delivery-step-card" key={step.title}>
                  <Icon color="var(--cyan)" />
                  <h3>{step.title}</h3>
                  <p>{step.text}</p>
                </div>
              );
            })}
          </div>
        </section>

        <HomeShowcaseSlider title="Clipora production categories" subtitle="A moving showcase for Clipora production categories: video, web, apps, avatars, brand files and e-commerce." slides={categorySlides(siteContent.showcaseSlides)} />

        <CategoryGroupBrowser />

        <div style={{ marginTop: 24 }}>
          <Link className="btn" href="/dashboard/assistant-workspace">Start a request</Link>
        </div>
      </main>
    </>
  );
}
