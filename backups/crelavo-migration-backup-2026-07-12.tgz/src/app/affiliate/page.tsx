import type { Metadata } from "next";
import Link from "next/link";
import { Header } from "@/components/Header";
import { PartnerApplicationForm } from "@/components/PartnerApplicationForm";
import { getConfiguredSiteContentConfig } from "@/lib/site-content-loader";
import { partnerAssets, partnerAudienceSegments, partnerCommissionDefaults, partnerLaunchChecklist, partnerPackageCommissionRules, partnerWorkflowStages } from "@/lib/partner-program";

const siteUrl = process.env.NEXT_PUBLIC_APP_URL ?? "https://cliporastudio.ai";

const affiliateEarningExamples = [
  { plan: "Starter Intelligence Agent", monthlyPrice: "$179/mo", commission: "35% draft", estimatedMonthly: "$62.65 per active customer" },
  { plan: "Growth Intelligence Agent", monthlyPrice: "$499/mo", commission: "35% draft", estimatedMonthly: "$174.65 per active customer" },
  { plan: "Enterprise Intelligence Agent", monthlyPrice: "$1,999/mo", commission: "35% draft", estimatedMonthly: "$699.65 per active customer" }
];

export const metadata: Metadata = {
  title: "Clipora Partner Program — Affiliate and Creator Rewards",
  description: "Apply for early access to the Clipora Partner Program for AI, no-code, creator, ecommerce and agency audiences.",
  alternates: { canonical: "/affiliate" },
  openGraph: { title: "Clipora Partner Program", description: "Early partner access for AI and no-code creators.", url: "/affiliate", type: "website" }
};

function PartnerStructuredData() {
  const schema = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebPage",
        "@id": `${siteUrl}/affiliate#webpage`,
        url: `${siteUrl}/affiliate`,
        name: "Clipora Partner Program",
        description: "Early partner access for creators, AI educators, no-code reviewers, agencies and growth partners.",
        inLanguage: "en-US",
        isPartOf: { "@id": `${siteUrl}/#website` }
      },
      {
        "@type": "Organization",
        "@id": `${siteUrl}/#organization`,
        name: "Clipora Studio",
        url: siteUrl
      }
    ]
  };

  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />;
}

export default async function AffiliatePage() {
  const siteContent = await getConfiguredSiteContentConfig();

  return (
    <>
      <PartnerStructuredData />
      <Header navLinks={siteContent.navLinks} />
      <main className="container section tools-page affiliate-page">
        <section className="production-hero-card admin-overview-hero">
          <span className="badge">Partner Program</span>
          <h1>Earn by introducing creators and businesses to Clipora Studio</h1>
          <p>Apply for early partner access if you create AI, no-code, SaaS, ecommerce, agency or creator economy content. The program is being prepared so partner links, creator assets and commission settings are ready when tracking and payout APIs go live.</p>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 16 }}>
            <a className="btn" href="#apply">Apply for early access</a>
            <Link className="btn secondary" href="/pricing">View pricing</Link>
            <Link className="btn secondary" href="/free-tools">Try free tools</Link>
          </div>
        </section>

        <section className="admin-info-grid" style={{ marginTop: 20 }}>
          <div className="affiliate-tone-warm"><span>Draft commission</span><strong>{partnerCommissionDefaults.plannedRange}</strong><small>Final percent set before launch</small></div>
          <div className="affiliate-tone-cyan"><span>Launch mode</span><strong>Early access</strong><small>Applications first, payout after provider setup</small></div>
          <div className="affiliate-tone-purple"><span>Best channels</span><strong>TikTok + YouTube</strong><small>AI, no-code and product content</small></div>
          <div className="affiliate-tone-blue"><span>Tracking</span><strong>API-ready</strong><small>Referral codes and attribution after provider connection</small></div>
        </section>

        <section className="card admin-wide-card" style={{ marginTop: 20 }}>
          <span className="badge">Partner earnings</span>
          <h2>Growth Intelligence creates higher recurring affiliate value</h2>
          <p style={{ color: "var(--muted)" }}>The numbers below are example earnings based on the current 35% draft commission. Final payout percentage, eligibility, attribution window and payout provider will be confirmed before the public affiliate launch.</p>
          <div className="admin-info-grid">
            {affiliateEarningExamples.map((item) => (
              <div key={item.plan}>
                <span>{item.plan}</span>
                <strong>{item.estimatedMonthly}</strong>
                <small>{item.monthlyPrice} · {item.commission}</small>
              </div>
            ))}
          </div>
        </section>

        <section className="card admin-wide-card" style={{ marginTop: 20 }}>
          <span className="badge">Weekly payouts</span>
          <h2>Affiliate earnings are reviewed weekly and paid every Monday</h2>
          <p style={{ color: "var(--muted)" }}>{partnerCommissionDefaults.payoutSchedule}</p>
          <div className="admin-info-grid">
            <div><span>Collection window</span><strong>Monday-Sunday</strong><small>All referred paid conversions are grouped weekly</small></div>
            <div><span>Cutoff</span><strong>Sunday 23:59</strong><small>Sunday night finance review after cutoff</small></div>
            <div><span>Payout day</span><strong>Monday</strong><small>Approved commissions are paid weekly</small></div>
            <div><span>No-purchase leads</span><strong>Visible</strong><small>Partners can see signups even before a package is bought</small></div>
          </div>
        </section>

        <section className="card admin-wide-card" style={{ marginTop: 20 }}>
          <span className="badge">Variable commission</span>
          <h2>Commission changes by package margin and delivery cost</h2>
          <p style={{ color: "var(--muted)" }}>Affiliate commission is not one fixed rate for every product. Lower-cost or high-margin recurring services can receive stronger rates, while custom or high provider/API cost packages may use lower commission or manual approval.</p>
          <div className="admin-category-grid">
            {partnerPackageCommissionRules.map((rule) => (
              <div className="card admin-category-card" key={rule.packageGroup}>
                <span className="badge">{rule.defaultPercent}% default</span>
                <h3>{rule.packageGroup}</h3>
                <p><strong>Examples:</strong> {rule.examplePackages.join(", ")}</p>
                <p>{rule.note}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="admin-category-grid" style={{ marginTop: 20 }}>
          {partnerAudienceSegments.map((segment, index) => (
            <div className={`card admin-category-card affiliate-card-tone-${index % 5}`} key={segment}>
              <span className="badge">Ideal partner</span>
              <h2>{segment}</h2>
              <p>Creators with an audience that wants faster websites, apps, ecommerce assets, AI videos, brand kits, Growth Intelligence reports or production-ready delivery packages.</p>
            </div>
          ))}
        </section>

        <section className="card admin-wide-card" style={{ marginTop: 20 }}>
          <span className="badge">What partners will get</span>
          <h2>Prepared now, activated after tracking and payout API setup</h2>
          <div className="admin-category-grid">
            {partnerAssets.map((asset, index) => (
              <div className={`card admin-category-card affiliate-card-tone-${(index + 2) % 5}`} key={asset.title}>
                <span className="badge">{asset.status}</span>
                <h3>{asset.title}</h3>
                <p>{asset.detail}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="card admin-wide-card" style={{ marginTop: 20 }}>
          <span className="badge">Workflow</span>
          <h2>Partner journey from application to commission review</h2>
          <div className="admin-info-grid">
            {partnerWorkflowStages.map((stage, index) => (
              <div className={`affiliate-card-tone-${index % 5}`} key={stage}><span>Step {index + 1}</span><strong>{stage}</strong><small>{index < 4 ? "Ready before API" : "Activated after tracking/payout setup"}</small></div>
            ))}
          </div>
        </section>

        <section className="card admin-wide-card" id="apply" style={{ marginTop: 20 }}>
          <span className="badge">Apply</span>
          <h2>Apply for early partner access</h2>
          <p style={{ color: "var(--muted)" }}>This form is ready for intake. Email delivery starts after Resend/env setup. Commission payout starts only after tracking and payout provider testing.</p>
          <PartnerApplicationForm />
        </section>

        <section className="card admin-wide-card" style={{ marginTop: 20 }}>
          <span className="badge">Before live launch</span>
          <h2>What remains after this page is ready</h2>
          <ul>{partnerLaunchChecklist.map((item) => <li key={item}>{item}</li>)}</ul>
        </section>
      </main>
    </>
  );
}
