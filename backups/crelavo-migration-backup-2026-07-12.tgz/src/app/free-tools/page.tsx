import type { Metadata } from "next";
import Link from "next/link";
import { FreeToolsHubStructuredData } from "@/components/FreeToolsHubStructuredData";
import { Header } from "@/components/Header";
import { getConfiguredSiteContentConfig } from "@/lib/site-content-loader";
import { freeTools } from "@/lib/free-tools";

export const metadata: Metadata = {
  title: "Free AI Tools — Clipora Studio",
  description: "Free AI tools for hooks, prompts, product descriptions, captions, hashtags, landing page copy, ad copy and brand slogans.",
  alternates: { canonical: "/free-tools" }
};

export default async function FreeToolsPage() {
  const siteContent = await getConfiguredSiteContentConfig();
  return (
    <>
      <FreeToolsHubStructuredData />
      <Header navLinks={siteContent.navLinks} />
      <main className="container section tools-page free-tools-page">
        <section className="production-hero-card admin-overview-hero">
          <span className="badge">Free AI tools</span>
          <h1>Free AI tools to start faster</h1>
          <p>Use simple free tools for hooks, prompts, product descriptions, captions, ads, landing page copy and brand ideas. Then turn the result into a full Clipora production package with preview, final ZIP, source files, README and revision path.</p>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 16 }}>
            <Link className="btn" href="/dashboard/assistant-workspace">Open Clipora Assistant</Link>
            <Link className="btn secondary" href="/pricing">Get credits for full production</Link>
          </div>
        </section>
        <section className="card admin-wide-card" style={{ marginTop: 20 }}>
          <span className="badge">Free tool funnel</span>
          <h2>Generate a quick result, then continue into production</h2>
          <div className="admin-info-grid">
            <div><span>Step 1</span><strong>Use a free tool</strong><small>Create a hook, prompt, caption, ad script or product idea.</small></div>
            <div><span>Step 2</span><strong>Select the best result</strong><small>The selected output is carried into Assistant Workspace.</small></div>
            <div><span>Step 3</span><strong>Start production</strong><small>Turn the result into a delivery plan, credits and final package.</small></div>
            <div><span>Step 4</span><strong>Buy credits when ready</strong><small>Payment Link launch uses the same Clipora account email.</small></div>
          </div>
        </section>

        <section className="admin-category-grid" style={{ marginTop: 20 }}>
          {freeTools.map((tool) => (
            <Link className="card admin-category-card" href={`/free-tools/${tool.slug}`} key={tool.slug}>
              <span className="badge">{tool.category}</span>
              <h2>{tool.title}</h2>
              <p>{tool.description}</p>
              <small>{tool.keyword}</small>
            </Link>
          ))}
        </section>
      </main>
    </>
  );
}
