import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { FreeToolGenerator } from "@/components/FreeToolGenerator";
import { FreeToolStructuredData } from "@/components/FreeToolStructuredData";
import { Header } from "@/components/Header";
import { getConfiguredSiteContentConfig } from "@/lib/site-content-loader";
import { freeToolMap, freeTools } from "@/lib/free-tools";

export function generateStaticParams() {
  return freeTools.map((tool) => ({ toolSlug: tool.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ toolSlug: string }> }): Promise<Metadata> {
  const { toolSlug } = await params;
  const tool = freeToolMap.get(toolSlug);
  if (!tool) return {};
  return {
    title: `${tool.title} — Free AI Tool`,
    description: tool.description,
    alternates: { canonical: `/free-tools/${tool.slug}` },
    openGraph: { title: tool.title, description: tool.description, url: `/free-tools/${tool.slug}`, type: "website" }
  };
}

export default async function FreeToolPage({ params }: { params: Promise<{ toolSlug: string }> }) {
  const { toolSlug } = await params;
  const tool = freeToolMap.get(toolSlug);
  if (!tool) notFound();
  const siteContent = await getConfiguredSiteContentConfig();
  return (
    <>
      <FreeToolStructuredData tool={tool} />
      <Header navLinks={siteContent.navLinks} />
      <main className="container section tools-page free-tool-detail-page">
        <section className="production-hero-card admin-overview-hero">
          <span className="badge">Free AI tool</span>
          <h1>{tool.title}</h1>
          <p>{tool.description}</p>
        </section>

        <FreeToolGenerator tool={tool} />

        <article className="card admin-wide-card" style={{ marginTop: 18 }}>
          <span className="badge">How it helps</span>
          <h2>{tool.keyword} for faster production planning</h2>
          <p>{tool.title} helps users create a useful starting point before they open a full production workspace. Instead of beginning with a blank prompt, the user can shape an idea, hook, caption, product description, ad script or brand message first.</p>
          <p>After the quick result, Clipora can route the idea into Assistant Workspace where the user can request preview, final ZIP, source files, README/setup notes, export notes and a revision path.</p>
        </article>
      </main>
    </>
  );
}
