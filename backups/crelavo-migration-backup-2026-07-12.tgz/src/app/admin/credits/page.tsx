import { AdminShell } from "@/components/AdminShell";
import { AdminCreditForm } from "@/components/AdminCreditForm";

export default function AdminCreditsPage() {
  return (
    <AdminShell title="Credit Operations" description="Manual credit activation, payment-link review notes, receipt references and credit operations.">
      <section className="card admin-wide-card">
        <h2>Manual credit activation</h2>
        <p style={{ color: "var(--muted)" }}>Use this after verifying a Stripe Payment Link payment in Stripe Dashboard, or to give a test user production credits for manual E2E. Add the same customer email, credit amount and receipt/invoice reference, then notify the user automatically.</p>
        <div className="workspace-action-note warning" style={{ marginBottom: 14 }}>
          Stripe remains the billing source of record for Payment Link receipts and invoices. Clipora sends the credit activation email after admin review and stores the receipt/invoice reference in the credit event note. Use this form for normal credit purchases and Drone / Satellite Video credit packs. Do not use it for AI Live Sales Agent service plans because those have 0 account credits.
        </div>
        <AdminCreditForm />
      </section>
    </AdminShell>
  );
}
