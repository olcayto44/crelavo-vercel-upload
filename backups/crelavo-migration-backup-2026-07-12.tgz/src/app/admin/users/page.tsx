import { AdminShell } from "@/components/AdminShell";
import { AdminUsersManager } from "@/components/AdminUsersManager";

export default function AdminUsersPage() {
  return (
    <AdminShell title="Members" description="Manage member search, user IP/location, user selection, credit additions and credit removals.">
      <AdminUsersManager />
    </AdminShell>
  );
}
