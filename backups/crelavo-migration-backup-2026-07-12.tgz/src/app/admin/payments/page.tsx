import Link from "next/link";
import { AdminShell } from "@/components/AdminShell";

const paymentLinkSteps = [
  "Create Stripe Payment Links for each subscription, top-up, Live Sales service plan, Growth Intelligence service plan and Drone credit pack in Stripe Dashboard.",
  "Paste each buy.stripe.com link into /admin/packages for the matching monthly, yearly or one-time package.",
  "Ask customers to use the same email as their Clipora account at Stripe checkout.",
  "Verify the payment, receipt or invoice in Stripe Dashboard.",
  "For normal credit products, open /admin/credits, add credits to the matching user email and paste the Stripe receipt/invoice reference.",
  "For Drone / Satellite credit packs, activate credits like other one-time top-ups while keeping the purchase page separate. For Live Sales and Growth Intelligence, do not add normal credits; verify the service payment separately. Growth Intelligence report files should be visible only after active entitlement or enough credits are confirmed."
];

const standalonePaymentControls = [
  { title: "AI Live Sales Agent", route: "/admin/live-sales-agent", purchase: "/live-sales-credits", policy: "Monthly service_subscription, 0 credits, fair-use live hours, pay-as-you-go provider/API usage after cost analysis." },
  { title: "AI Growth Intelligence", route: "/admin/packages", purchase: "/growth-intelligence", policy: "Monthly service_subscription, 0 credits, public-signal competitor monitoring, gated dashboard PDF/file delivery and alert-channel service limits." },
  { title: "Drone / Satellite Video", route: "/admin/drone-video", purchase: "/drone-credits", policy: "Separate one-time drone credit packs. Payment adds credits like other top-ups; production scope is tracked from the drone brief." }
];

const futureAutomationSteps = [
  "Add STRIPE_SECRET_KEY, NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY and STRIPE_WEBHOOK_SECRET only during final API setup.",
  "Add every STRIPE_PRICE_* env value for API checkout fallback.",
  "Run checkout.session.completed, invoice.paid, invoice.payment_failed and subscription status webhook tests.",
  "Only enable automatic credit activation after duplicate-credit and idempotency tests pass."
];

export default function AdminPaymentsPage() {
  return (
    <AdminShell title="Payment readiness" description="Review Stripe Payment Link launch, manual credit activation, receipts/invoices and future Stripe API/webhook automation.">
      <section className="card admin-wide-card">
        <span className="badge">Current launch mode</span>
        <h2>Stripe Payment Links + manual credit activation</h2>
        <p style={{ color: "var(--muted)" }}>
          Early launch can accept payments through Stripe Payment Links without requiring Stripe API keys. Stripe remains the source of record for receipts and invoices. Clipora activates credits after admin review and sends the user a credits activated email.
        </p>
        <div className="admin-info-grid" style={{ marginTop: 14 }}>
          <div><span>Payment collection</span><strong>Stripe Payment Links</strong><small>Configured from /admin/packages</small></div>
          <div><span>Receipt / invoice</span><strong>Stripe</strong><small>Customer email settings must be enabled in Stripe</small></div>
          <div><span>Credit activation</span><strong>Normal credits only</strong><small>/admin/credits stores receipt references for credit plans and top-ups</small></div>
          <div><span>Standalone products</span><strong>Mixed policy</strong><small>Live Sales and Growth Intelligence are service-only; Drone stays separate but adds credits like top-ups</small></div>
        </div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 14 }}>
          <Link className="btn" href="/admin/packages">Configure Payment Links</Link>
          <Link className="btn secondary" href="/admin/credits">Activate Credits</Link>
          <Link className="btn secondary" href="/admin/manual-e2e-checklist">Manual E2E Checklist</Link>
        </div>
      </section>

      <section className="card admin-wide-card" style={{ marginTop: 20 }}>
        <span className="badge">Standalone payments</span>
        <h2>Live Sales, Growth Intelligence and Drone use separate payment policies</h2>
        <div className="admin-info-grid">
          {standalonePaymentControls.map((item) => (
            <div key={item.title}>
              <span>{item.title}</span>
              <strong>{item.policy}</strong>
              <small><Link href={item.route}>Admin operations</Link> · <Link href={item.purchase}>Public purchase page</Link></small>
            </div>
          ))}
        </div>
      </section>

      <section className="card admin-wide-card" style={{ marginTop: 20 }}>
        <span className="badge">Operational checklist</span>
        <h2>Payment Link activation sequence</h2>
        <div className="admin-info-grid">
          {paymentLinkSteps.map((step, index) => (
            <div key={step}>
              <span>Step {index + 1}</span>
              <strong>{step}</strong>
              <small>Required for controlled Payment Link launch.</small>
            </div>
          ))}
        </div>
      </section>

      <section className="card admin-wide-card" style={{ marginTop: 20 }}>
        <span className="badge">Later automation</span>
        <h2>Stripe API/webhook path stays available for a later upgrade</h2>
        <div className="workspace-action-note warning" style={{ marginBottom: 14 }}>
          Do not enable automatic credit activation until live Stripe webhook tests, duplicate-payment safeguards and idempotency checks pass.
        </div>
        <div className="admin-info-grid">
          {futureAutomationSteps.map((step, index) => (
            <div key={step}>
              <span>Future step {index + 1}</span>
              <strong>{step}</strong>
              <small>Not required for Payment Link launch.</small>
            </div>
          ))}
        </div>
      </section>
    </AdminShell>
  );
}
