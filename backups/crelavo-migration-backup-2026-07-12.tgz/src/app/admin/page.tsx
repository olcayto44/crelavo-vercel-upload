import Link from "next/link";
import { AdminShell } from "@/components/AdminShell";
import { AdminStatsCards } from "@/components/AdminStatsCards";
import { AdminFinanceCards } from "@/components/AdminFinanceCards";
import { AdminLiveVisitorsCard } from "@/components/AdminLiveVisitorsCard";
import { buildFinalApiChecklist } from "@/lib/final-api-checklist";
import { buildLaunchReadiness } from "@/lib/launch-readiness";
import { buildManualE2EChecklist } from "@/lib/manual-e2e-checklist";

function commandStatusClass(status: string) {
  if (["ready", "go", "ready_for_live_e2e"].includes(status.toLowerCase())) return "ready";
  if (["blocked", "missing", "no_go"].includes(status.toLowerCase())) return "failed";
  return "active";
}

function commandStatusLabel(value: string) {
  return value.replaceAll("_", " ").replace(/\b\w/g, (char) => char.toUpperCase());
}

function hasEnv(name: string) {
  const value = process.env[name];
  return Boolean(value && !value.includes("TODO") && !value.includes("your_") && !value.includes("change_me"));
}

const quickModules = [
  { title: "Members", href: "/admin/users", note: "Search users, view IP/country/city/credit data, and add or remove credits." },
  { title: "All Requests", href: "/admin/productions", note: "Manage user production requests, delivery links and status updates." },
  { title: "Launch Readiness", href: "/admin/launch-readiness", note: "Check env keys, domain, Stripe, email, providers, safe capacity policy and manual launch blockers." },
  { title: "Final API Checklist", href: "/admin/final-api-checklist", note: "Use on final setup day to connect Stripe, Supabase, Resend and provider keys, then run live E2E in order." },
  { title: "Manual E2E Checklist", href: "/admin/manual-e2e-checklist", note: "Track pre-API and final API browser checks with PASS, FAIL and BLOCKED launch validation states." },
  { title: "Provider Readiness", href: "/admin/providers", note: "Review Claude/OpenAI, image, video, voice, render, email and payment provider routing before final API setup." },
  { title: "Growth Backlog", href: "/admin/growth", note: "Post-launch growth planning after core launch validation: referral, share loops, analytics and organic launch assets." },
  { title: "Partner Program", href: "/admin/partners", note: "Prepare affiliate applications, creator assets, commission placeholders and API launch blockers before payout tracking goes live." },
  { title: "E-commerce Product Ad", href: "/admin/ecommerce-product-ad", note: "Monitor product-link campaign planning, provider preflight, delivery package and final dashboard output status." },
  { title: "Connected Accounts & Stores", href: "/admin/connections", note: "Phase-2 backlog for future social/store targets, export planning and API-dependent publishing." },
  { title: "Packages", href: "/admin/packages", note: "Management area for credit packages and production packages." },
  { title: "Category Cards", href: "/admin/categories", note: "Edit site category cards and add new cards." },
  { title: "SEO / Google", href: "/admin/seo", note: "Sitemap, robots, meta, Google and social sharing settings." },
  { title: "Ad Slots", href: "/admin/ads", note: "Splash, right/left, sidebar, header and in-content ad slots." },
  { title: "Appearance / Theme", href: "/admin/appearance", note: "Header, sidebar, color, card, landing page and module appearance settings." },
  { title: "Code Backup", href: "/admin/backup", note: "Full code backup, restore and secure archive area for the site." }
];

export default function AdminPage() {
  const launchReadiness = buildLaunchReadiness();
  const finalApiChecklist = buildFinalApiChecklist();
  const manualE2E = buildManualE2EChecklist();
  const paymentLinkModeReady = !hasEnv("STRIPE_SECRET_KEY") || !hasEnv("STRIPE_WEBHOOK_SECRET");
  const commandCards = [
    {
      title: "Launch Readiness",
      href: "/admin/launch-readiness",
      status: launchReadiness.summary.goNoGo,
      metric: `${launchReadiness.summary.readyCount}/${launchReadiness.summary.totalCount}`,
      note: `${launchReadiness.summary.hardBlockerCount} hard blockers · ${launchReadiness.summary.softBlockerCount} soft blockers`
    },
    {
      title: "Final API Checklist",
      href: "/admin/final-api-checklist",
      status: finalApiChecklist.summary.status,
      metric: `${finalApiChecklist.summary.readyCount}/${finalApiChecklist.summary.totalCount}`,
      note: `${finalApiChecklist.summary.missingCount} missing final env/API checks`
    },
    {
      title: "Manual E2E Checklist",
      href: "/admin/manual-e2e-checklist",
      status: manualE2E.summary.blocked ? "pending" : "ready",
      metric: `${manualE2E.preApiItems} pre-API`,
      note: `${manualE2E.finalApiItems} final API checks remain separated`
    },
    {
      title: "Payment Link Launch",
      href: "/admin/packages",
      status: paymentLinkModeReady ? "pending" : "ready",
      metric: paymentLinkModeReady ? "Manual activation" : "API checkout",
      note: paymentLinkModeReady
        ? "Use Stripe Payment Links, then activate credits from /admin/credits with receipt reference."
        : "Stripe API keys are present; full checkout/webhook testing can run."
    },
    {
      title: "Service Pages",
      href: "/admin/service-pages",
      status: "pending",
      metric: "Publish controls",
      note: "Draft/noindex/sitemap/FAQ/internal link controls are ready for admin review."
    }
  ];

  return (
    <AdminShell
      title="Clipora Admin Panel"
      description="A detailed control center similar to WordPress: members, requests, packages, categories, SEO, ads, appearance, payments and backups are managed from one panel."
    >
      <section className="card admin-user-info-card">
        <span className="badge">Control center</span>
        <h2>Quick access for site management</h2>
        <p style={{ color: "var(--muted)" }}>
          This main panel is only a summary screen. Each management area opens as a separate page from the left menu and contains its own settings.
        </p>
        <div className="admin-info-grid">
          <div><span>Member management</span><strong>Search + credit operations</strong><small>On the Members page</small></div>
          <div><span>Content management</span><strong>Categories + packages</strong><small>Cards are editable</small></div>
          <div><span>Site settings</span><strong>SEO + appearance + ads</strong><small>WordPress-like structure</small></div>
          <div><span>Security</span><strong>Code backup</strong><small>Ready area for restore</small></div>
        </div>
      </section>

      <section className="card admin-wide-card" style={{ marginTop: 20 }}>
        <span className="badge">Launch Command Center</span>
        <h2>Pre-launch control summary</h2>
        <p style={{ color: "var(--muted)" }}>
          Use this overview to move between launch readiness, final API setup, manual E2E, Payment Link activation and SEO/service-page publishing without opening every page first.
        </p>
        <div className="admin-info-grid launch-readiness-summary" style={{ marginTop: 14 }}>
          <div><span>Go / no-go</span><strong>{commandStatusLabel(launchReadiness.summary.goNoGo)}</strong><small>{launchReadiness.summary.status}</small></div>
          <div><span>Ready checks</span><strong>{launchReadiness.summary.readyCount}/{launchReadiness.summary.totalCount}</strong><small>Launch readiness items</small></div>
          <div><span>Final env missing</span><strong>{finalApiChecklist.summary.missingCount}</strong><small>Keys and live provider checks</small></div>
          <div><span>Payment mode</span><strong>{paymentLinkModeReady ? "Payment Links" : "Stripe API"}</strong><small>{paymentLinkModeReady ? "Manual credit activation" : "Webhook testing available"}</small></div>
        </div>
        <div className="admin-category-grid" style={{ marginTop: 14 }}>
          {commandCards.map((card) => (
            <Link className="card admin-category-card" href={card.href} key={card.href}>
              <span className={`provider-job-chip ${commandStatusClass(card.status)}`}>{commandStatusLabel(card.status)}</span>
              <h2>{card.title}</h2>
              <strong>{card.metric}</strong>
              <p>{card.note}</p>
              <span className="btn">Open</span>
            </Link>
          ))}
        </div>
        <div className="workspace-action-note warning" style={{ marginTop: 14 }}>
          Current payment fallback: Stripe Payment Links can be used without Stripe API keys. After verifying the Stripe receipt/invoice in Stripe Dashboard, activate credits from /admin/credits so the user receives a Clipora credits activated email.
        </div>
      </section>

      <section className="admin-panel-section"><AdminLiveVisitorsCard /></section>
      <section className="admin-panel-section"><AdminStatsCards /></section>
      <section className="admin-panel-section"><AdminFinanceCards /></section>

      <section className="admin-category-grid">
        {quickModules.map((item) => (
          <Link className="card admin-category-card" href={item.href} key={item.href}>
            <span className="badge">Admin module</span>
            <h2>{item.title}</h2>
            <p>{item.note}</p>
            <span className="btn">Open module</span>
          </Link>
        ))}
      </section>
    </AdminShell>
  );
}
