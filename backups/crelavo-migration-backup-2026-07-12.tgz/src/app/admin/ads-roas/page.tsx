import { AdminShell } from "@/components/AdminShell";

export default function AdminAdsRoasPage() {
  return (
    <AdminShell title="Ads & ROAS Backlog" description="Phase-2 planning for future OAuth connections, ad/export plans and ROAS review loops. Live ad launch and direct publishing wait for final API/env setup.">
      <div className="grid">
        <div className="card">
          <span className="badge">Future OAuth</span>
          <h3>Sosyal hesap planları</h3>
          <p>connected_ad_accounts tablosu gelecekteki Meta, Instagram, TikTok, YouTube, LinkedIn ve X hedeflerini izler; canlı OAuth final API/env sonrası açılır.</p>
        </div>
        <div className="card">
          <span className="badge">Planning</span>
          <h3>Campaign / post / export plan</h3>
          <p>ad_campaign_jobs tablosu sosyal platform, plan payload, future external id ve hata durumlarını saklar; canlı publish launch şimdilik kapalıdır.</p>
        </div>
        <div className="card">
          <span className="badge">ROAS</span>
          <h3>AI optimizasyon</h3>
          <p>ROAS düşükse gelecekte reklam durdurma, yeni hook üretme veya platforma özel varyasyon önerisi planlanır; canlı optimizasyon final API/env sonrasına kalır.</p>
        </div>
      </div>
    </AdminShell>
  );
}
