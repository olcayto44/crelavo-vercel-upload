import { AdminShell } from "@/components/AdminShell";
import { AdminGrowthIntelligenceRequests } from "@/components/AdminGrowthIntelligenceRequests";
import { growthWorkstreams, launchChannelPriorities, launchGrowthSequence, rewardCreditRules, watermarkPolicy } from "@/lib/growth";

function statusLabel(status: string) {
  if (status === "ready_for_build") return "Ready for build";
  if (status === "blocked_by_stripe") return "Blocked by Stripe";
  if (status === "blocked_by_domain") return "Blocked by domain";
  return "Planned";
}

export default function AdminGrowthPage() {
  return (
    <AdminShell title="Growth backlog" description="Post-launch growth plan: referral, team workspace, social export, analytics and publishing automation after core launch validation.">
      <section className="card admin-wide-card">
        <span className="badge">Phase 2 / post-launch</span>
        <h2>Growth priorities after core launch</h2>
        <p style={{ color: "var(--muted)" }}>These items should not interrupt the current pre-API launch cleanup. Payment conversion, payouts, live social publishing and API-driven automation stay blocked until final API/env setup and real E2E tests are complete. Stripe/domain dependencies remain tracked separately.</p>
        <div className="admin-info-grid">
          <div><span>P1</span><strong>Watermark</strong><small>Free preview watermark and paid watermark-free rules.</small></div>
          <div><span>P1</span><strong>Share-to-earn</strong><small>Capped reward credits for verified sharing actions.</small></div>
          <div><span>P1</span><strong>Referral / affiliate</strong><small>Track referral journey now; connect paid attribution after Stripe.</small></div>
          <div><span>P2</span><strong>Analytics</strong><small>Usage and provider signals before revenue metrics.</small></div>
        </div>
      </section>

      <section className="card admin-wide-card" style={{ marginTop: 20 }}>
        <span className="badge">Growth Intelligence delivery</span>
        <h2>Report requests and dashboard PDF/file delivery</h2>
        <p style={{ color: "var(--muted)" }}>Review Growth Intelligence briefs, confirm entitlement/credit eligibility and paste the final PDF/report file URL for dashboard delivery.</p>
        <AdminGrowthIntelligenceRequests />
      </section>

      <section className="card admin-wide-card" style={{ marginTop: 20 }}>
        <span className="badge">Launch growth sequence</span>
        <h2>What to do first, next and last</h2>
        <div className="admin-info-grid">
          {launchGrowthSequence.map((item) => (
            <div key={item.phase}>
              <span>{item.priority}</span>
              <strong>{item.phase}</strong>
              <small>{item.focus}</small>
            </div>
          ))}
        </div>
      </section>

      <section className="card admin-wide-card" style={{ marginTop: 20 }}>
        <span className="badge">Channel priority</span>
        <h2>TikTok, YouTube Shorts and Free Tools lead the launch</h2>
        <div className="admin-category-grid">
          {launchChannelPriorities.map((item) => (
            <div className="card admin-category-card" key={item.channel}>
              <span className="badge">{item.status}</span>
              <h3>{item.channel}</h3>
              <p>{item.angle}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="admin-category-grid">
        {growthWorkstreams.map((item) => (
          <div className="card admin-category-card" key={item.id}>
            <span className="badge">{item.priority} · {statusLabel(item.status)}</span>
            <h2>{item.title}</h2>
            <p>{item.summary}</p>
            <p><strong>User value:</strong> {item.userValue}</p>
            {item.blockedUntil ? <p className="workspace-action-note warning">{item.blockedUntil}</p> : null}
            <h3>Admin checks</h3>
            <ul>{item.adminChecks.map((check) => <li key={check}>{check}</li>)}</ul>
            <h3>Next steps</h3>
            <ul>{item.nextSteps.map((step) => <li key={step}>{step}</li>)}</ul>
          </div>
        ))}
      </section>

      <section className="card admin-wide-card">
        <span className="badge">Reward credits</span>
        <h2>Share-to-earn draft rules</h2>
        <div className="admin-info-grid">
          {rewardCreditRules.map((rule) => (
            <div key={rule.action}>
              <span>{rule.action}</span>
              <strong>{rule.credits.toLocaleString()} credits</strong>
              <small>{rule.limit}</small>
            </div>
          ))}
        </div>
      </section>

      <section className="card admin-wide-card">
        <span className="badge">Watermark policy</span>
        <h2>Preview/final delivery rules</h2>
        <ul>{watermarkPolicy.map((rule) => <li key={rule}>{rule}</li>)}</ul>
      </section>
    </AdminShell>
  );
}
