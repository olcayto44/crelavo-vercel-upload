import { AdminShell } from "@/components/AdminShell";

const seoModules = [
  { title: "Meta title / description", file: "app metadata", fields: ["Default title", "Default description", "Page keywords", "Canonical base URL"] },
  { title: "Sitemap.xml", file: "src/app/sitemap.ts", fields: ["Static routes", "Dashboard routes", "Admin routes", "Last modified policy"] },
  { title: "Robots.txt", file: "src/app/robots.ts", fields: ["Allow rules", "Disallow admin", "Sitemap URL", "Crawler policy"] },
  { title: "Google Search Console", file: "verification meta", fields: ["Verification code", "Domain property", "Sitemap submit status", "Indexing notes"] },
  { title: "Google Analytics / Tag Manager", file: "layout script area", fields: ["GA measurement ID", "GTM container ID", "Cookie consent", "Conversion events"] },
  { title: "Open Graph", file: "social preview config", fields: ["OG title", "OG description", "OG image", "Twitter card"] }
];

export default function AdminSeoPage() {
  return (
    <AdminShell title="SEO / Sitemap / Google" description="SEO dosyaları, Google ayarları, sitemap, robots, meta ve sosyal paylaşım önizlemelerini yönet.">
      <section className="admin-category-grid">
        {seoModules.map((module) => (
          <div className="card admin-category-card" key={module.title}>
            <span className="badge">{module.file}</span>
            <h2>{module.title}</h2>
            <div className="admin-production-editor">
              {module.fields.map((field) => (
                <div className="field" key={field}>
                  <label>{field}</label>
                  <input placeholder={`${field} değerini gir`} />
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
              <button className="btn" type="button">Ayarları uygula</button>
              <button className="btn secondary" type="button">Dosyayı görüntüle</button>
            </div>
          </div>
        ))}
      </section>

      <section className="card admin-wide-card">
        <h2>SEO sistem notu</h2>
        <p style={{ color: "var(--muted)" }}>Arayüz hazır. Sonraki adımda bu alanlar gerçek sitemap.ts, robots.ts, metadata ve Google script alanlarına bağlanacak.</p>
      </section>
    </AdminShell>
  );
}
