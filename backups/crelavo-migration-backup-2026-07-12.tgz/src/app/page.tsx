import { Boxes, Clapperboard, Grid3X3, Image, Layers3, MonitorPlay, Plane, RadioTower, Sparkles, Wand2 } from "lucide-react";
import { AdSlot } from "@/components/AdSlot";
import { FaqSection } from "@/components/FaqSection";
import { FaqStructuredData } from "@/components/FaqStructuredData";
import { CampaignPromoSlot } from "@/components/CampaignPromoSlot";
import { HardReloadLink } from "@/components/HardReloadLink";
import { Header } from "@/components/Header";
import { HomeShowcaseSlider, type HomeShowcaseSlide } from "@/components/HomeShowcaseSlider";
import { SampleVideoGallery } from "@/components/SampleVideoGallery";
import { SiteStructuredData } from "@/components/SiteStructuredData";
import { SplashAd } from "@/components/SplashAd";
import { getConfiguredSampleVideos } from "@/lib/sample-video-config";
import { getConfiguredSiteContentConfig } from "@/lib/site-content-loader";
import { categoryShowcaseItems, featureShowcaseItems } from "@/lib/showcase-items";

const platformHighlights = [
  "Campaigns",
  "AI Agents",
  "Video & MV",
  "Web / App / SaaS",
  "Brand & Files"
];

const appLauncherSlides: HomeShowcaseSlide[] = [
  { title: "Explore", kicker: "Samples", description: "Browse large sample outputs and open dedicated detail pages.", href: "/showcase/explore-samples", tone: "cyan", imageUrl: "https://cdn.hailuoai.video/moss/prod/2026-07-05-03/image/1783192157407622951-1783192157402.png" },
  { title: "Assets", kicker: "Materials", description: "Use images, videos, audio references and documents across productions.", href: "/showcase/assets-library", tone: "green", imageUrl: "https://cdn.hailuoai.video/moss/prod/2026-07-05-03/image/1783192199380895416-1783192199376.png" },
  { title: "Omni", kicker: "Assistant", description: "Tell Clipora what you want to create and let the system route the workflow.", href: "/showcase/omni-assistant", tone: "blue", imageUrl: "https://cdn.hailuoai.video/moss/prod/2026-07-05-03/image/1783192218134042523-1783192218131.png" },
  { title: "Generate", kicker: "Create", description: "Start video, web, app, brand file or visual production from one hub.", href: "/showcase/generate-hub", tone: "pink", imageUrl: "https://cdn.hailuoai.video/moss/prod/2026-07-05-03/image/1783192231039044746-1783192231031.png" },
  { title: "Workspace", kicker: "Live tracking", description: "Track live productions, revisions, outputs and final delivery packages.", href: "/showcase/live-workspace", tone: "amber", imageUrl: "https://cdn.hailuoai.video/moss/prod/2026-07-05-03/image/1783192247858193551-1783192247854.png" },
  { title: "Drone", kicker: "Aerial style", description: "Plan AI map/location drone-style videos and future aerial production workflows from Clipora.", href: "/showcase/drone-aerial-video", tone: "cyan", imageUrl: "https://cdn.hailuoai.video/moss/prod/2026-07-05-03/image/1783192231039044746-1783192231031.png" },
  { title: "All Tools", kicker: "Catalog", description: "Open the full tool catalog and choose the right production entry.", href: "/showcase/all-tools", tone: "purple", imageUrl: "https://cdn.hailuoai.video/moss/prod/2026-07-05-03/image/1783192261949279707-1783192261944.png" }
];

const featuredTools = [
  { title: "AI Video Generator", href: "/tools/ai-video-generator", icon: Clapperboard },
  { title: "AI Avatar Video Studio", href: "/tools/talking-video", icon: MonitorPlay },
  { title: "Drone Shoot", href: "/dashboard/drone-shoot", icon: Plane },
  { title: "Avatar Live Stream", href: "/dashboard/live-sales-agent", icon: RadioTower },
  { title: "Image & Visual Pack", href: "/tools/image-visual-pack", icon: Image },
  { title: "Website Builder", href: "/tools/website-builder", icon: Wand2 },
  { title: "SaaS / App Builder", href: "/tools/saas-app-builder", icon: Layers3 },
  { title: "Brand & Files", href: "/tools/brand-files", icon: Boxes }
];

type ShowcaseSection = "launcher" | "features" | "categories";

function slidesForSection(slides: (HomeShowcaseSlide & { section?: ShowcaseSection; order?: number; active?: boolean })[], section: ShowcaseSection, fallback: HomeShowcaseSlide[]) {
  const configured = slides
    .filter((slide) => slide.section === section && slide.active)
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  return configured.length ? configured : fallback;
}


export default async function HomePage() {
  const [configuredSampleVideos, siteContent] = await Promise.all([
    getConfiguredSampleVideos(),
    getConfiguredSiteContentConfig()
  ]);

  return (
    <>
      <FaqStructuredData />
      <SiteStructuredData />
      <SplashAd />
      <Header navLinks={siteContent.navLinks} />
      <main>
        <div className="page-with-rails">
          <aside className="ad-rail ad-rail-left"><AdSlot slotId="left-rail" /></aside>
          <aside className="ad-rail ad-rail-right"><AdSlot slotId="right-rail" /></aside>
          <section className="container section home-section-tight clean-feed-section home-platform-hero">
            <div>
            <span className="badge"><Sparkles size={16} /> Clipora Studio — AI production studio for websites, apps, e-commerce and campaigns</span>
            <h1>Launch websites, apps and product campaigns from one AI production studio.</h1>
            <p>
              Turn ideas, briefs, Shopify, Amazon or Trendyol product links into managed websites, mobile apps, e-commerce assets, ad videos, visuals, voice-over content and campaign-ready delivery packages.
            </p>
            <div className="home-highlight-row">
              {platformHighlights.map((item, index) => <span key={item}>{index > 0 ? " • " : ""}{item}</span>)}
            </div>
            </div>
            <div className="promo-corner-slot"><CampaignPromoSlot /></div>
          </section>


        <HomeShowcaseSlider title="Explore Clipora Studio" subtitle="A large moving entry showcase for samples, assets, Omni Assistant, generation, workspace tracking and the full tool catalog." slides={slidesForSection(siteContent.showcaseSlides, "launcher", appLauncherSlides)} />

        <HomeShowcaseSlider title="Seedance, Canvas and production features" subtitle="A Kling-style moving showcase for Clipora's AI engines, workspace and asset flow. Every slide has a different visual feel and feature." slides={slidesForSection(siteContent.showcaseSlides, "features", featureShowcaseItems)} />

        <section className="container section home-section-tight home-tool-strip-section">
          <div className="sample-video-head">
            <div>
              <span className="badge"><Grid3X3 size={15} /> All Tools</span>
              <h2>Choose a tool or let Omni Assistant decide</h2>
              <p className="section-lead">Start from video, visuals, websites, SaaS, apps, brand kits or production packages. Clipora routes the request into the right assistant workflow.</p>
            </div>
            <HardReloadLink className="btn secondary" href="/categories">Open all tools</HardReloadLink>
          </div>
          <div className="home-tool-strip-grid">
            {featuredTools.map((tool) => {
              const Icon = tool.icon;
              return (
                <HardReloadLink className="home-tool-pill" href={tool.href} key={tool.title}>
                  <Icon size={18} />
                  <span>{tool.title}</span>
                </HardReloadLink>
              );
            })}
          </div>
        </section>

        <section className="container section home-section-tight clean-feed-section">
          <div className="sample-video-head">
            <div>
              <span className="badge"><Sparkles size={15} /> Affiliate Program</span>
              <h2>Earn recurring commission by promoting Clipora Studio</h2>
              <p className="section-lead">Creators, agencies and growth partners can apply for early affiliate access. Growth Intelligence, Live Sales and production packages create higher-ticket referral opportunities than normal credit top-ups.</p>
            </div>
            <HardReloadLink className="btn" href="/affiliate">Open affiliate page</HardReloadLink>
          </div>
          <div className="admin-info-grid" style={{ marginTop: 14 }}>
            <div><span>Draft commission</span><strong>30-40%</strong><small>Final payout terms set before launch</small></div>
            <div><span>High-ticket offer</span><strong>Growth Intelligence</strong><small>$179, $499 and $1,999 monthly service plans</small></div>
            <div><span>Best channels</span><strong>TikTok + YouTube Shorts</strong><small>AI tools, ecommerce, no-code and agency content</small></div>
            <div><span>Partner dashboard</span><strong>Prepared</strong><small>Referral links, earnings and payout review after provider setup</small></div>
          </div>
        </section>

        <HomeShowcaseSlider title="Clipora production categories" subtitle="A second moving showcase for video, web, apps, avatars, brand files, e-commerce, music videos and animation with optional uploaded image/voice or selected/generated character and voice." slides={slidesForSection(siteContent.showcaseSlides, "categories", categoryShowcaseItems)} reverse />

<section id="sample-outputs" className="container section home-section-tight clean-feed-section top-sample-section">
  <SampleVideoGallery title="Explore sample outputs" subtitle="Large Kling-style cards open a dedicated sample page. Details, features and create actions appear after clicking the card." videos={configuredSampleVideos} shuffleOnLoad />
</section>
        <FaqSection />
        <AdSlot slotId="footer" />
        </div>
      </main>
    </>
  );
}
