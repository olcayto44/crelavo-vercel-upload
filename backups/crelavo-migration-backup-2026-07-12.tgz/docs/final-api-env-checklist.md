# Final API / Env Checklist

Use this only after all pre-API launch cleanup is complete. Do not paste real secrets into chat or documentation; add them only to local `.env.local` and deployment environment variables.

## Current rule

API/env key setup is deferred until final testing. Before that point, complete code, UI, admin cleanup, launch readiness, security/privacy review, non-payment E2E and dry-run validation.

## Required before final payment/email/provider E2E

### App and admin

```text
NEXT_PUBLIC_APP_URL=https://cliporastudio.ai
ADMIN_EMAIL=
PAYMENT_NOTIFICATION_EMAIL=
```

### Supabase

```text
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
SUPABASE_PROVIDER_ASSETS_BUCKET=provider-assets
SUPABASE_USER_MATERIALS_BUCKET=user-materials
```

### Stripe core

```text
STRIPE_SECRET_KEY=
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=
STRIPE_WEBHOOK_SECRET=
```

### Stripe package price IDs

Keep these aligned with `/admin/packages` and `/api/admin/stripe-readiness`.

```text
STRIPE_PRICE_PRO_MONTHLY=
STRIPE_PRICE_PRO_YEARLY=
STRIPE_PRICE_BUSINESS_MONTHLY=
STRIPE_PRICE_BUSINESS_YEARLY=
STRIPE_PRICE_ULTRA_MONTHLY=
STRIPE_PRICE_ULTRA_YEARLY=
STRIPE_PRICE_TEAM_MONTHLY=
STRIPE_PRICE_TEAM_YEARLY=
STRIPE_PRICE_TOPUP_STARTER=
STRIPE_PRICE_TOPUP_CREATOR=
STRIPE_PRICE_TOPUP_BUSINESS=
```

### Resend / email

```text
RESEND_API_KEY=
SUPPORT_EMAIL=support@cliporastudio.ai
SUPPORT_FROM_EMAIL=Clipora Studio <support@cliporastudio.ai>
```

Before email E2E, also verify Supabase Auth email confirmation, Supabase SMTP settings, Resend DNS verification, SPF / DKIM / DMARC and sender domain status.

### OpenAI / provider

```text
OPENAI_API_KEY=
OPENAI_ASSISTANT_MODEL=gpt-4o-mini
VIDEO_PROVIDER=replicate
GENERATION_PROVIDER=replicate
REPLICATE_API_TOKEN=
REPLICATE_MODEL=wan-video/wan-2.2-t2v-fast
```

If provider changes, use one of the matching keys:

```text
FAL_KEY= or FAL_API_KEY=
RUNWAY_API_KEY=
KLING_API_KEY=
```

## Validation commands after external setup

Run after Stripe, Resend, Supabase, OpenAI and selected provider env values are present:

```bash
npm run smoke:env-readiness
npm run smoke
npm run build
```

Then run the browser/manual pass from:

```text
docs/manual-e2e-checklist.md
docs/manual-e2e-results.md
```

## Final live E2E order

1. Confirm `/admin/launch-readiness` shows no missing env blocker except manual domain/DNS checks.
2. Open `/admin/packages`, enter `ADMIN_EMAIL`, click `Check Stripe env`, confirm missing env names are `None`.
3. Register/login with a real test user.
4. Confirm welcome assistant credits.
5. Run Assistant Brain planning from `/dashboard/assistant-workspace`.
6. Start one production with enough credits or test package.
7. Run one Stripe checkout.
8. Verify `checkout.session.completed` webhook adds credits.
9. Verify customer payment receipt email.
10. Verify owner/admin payment notification email.
11. Test subscription renewal paid and payment failed webhook events.
12. Complete one provider-success production path.
13. Confirm production-ready email.
14. Confirm production detail preview/delivery links.
15. Confirm admin can update preview/delivery manually without blocking customer view.

## Still blocked until keys are added

- Real Stripe checkout.
- Real Stripe webhook.
- Paid credit purchase.
- Subscription renewal/payment failure E2E.
- Resend production delivery tests.
- Live domain redirect tests.
- Search Console/domain indexing verification.
